/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package objects;

import java.util.Random;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class StringsAndNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("******** String Class ********");
        
        String s = "  Welcome     to   the first    Lab Activity  in the    OOP Course ";
        System.out.println(s);
        System.out.println("The length of the string is: " + s.length());
       
        String s1 = "Welcome";
        System.out.println(s1.toUpperCase());
        
        String s2 = "to";
        System.out.println(s2.toUpperCase());
        
        String s3 = "the  first";
        System.out.println(s3.toUpperCase());
        
        String s4 = "Lab  Activity";
        System.out.println(s4.toUpperCase());
        
        String s5 = "in  the";
        System.out.println(s5.toUpperCase());
        
        String s6 = "OOP Course.";
        System.out.println(s6.toUpperCase());
        
        String a = "lab-interesting-activities-are-activities-lab-Interesting-Lab-Activities-Are Interesting Lab activities Lab Interesting";
       
        
        System.out.println(a);
        System.out.println("First occurrence of Interesting is at: " + a.indexOf("Interesting"));
        String b = a.replace('-', '_');
        System.out.println(b.replace(' ', '-'));
        
        System.out.println("I have done my undergraduation in computer science and i want to expertise my knowledge so thats why i have choosen applied computer science in masters ");
        
        System.out.println("******** Math Class ********");
        
        double x = Math.pow(10, 2);
        double y = Math.pow(14, 2);
        double sum = (x + y);
        System.out.println("sqrt (10^2+14^2): " + Math.sqrt(sum));
         
        double tanp;
        double tanq;
        tanp = 60;
        tanq = 45;
        double r = Math.tan(tanp)-Math.tan(tanq);
        double t = Math.tan(tanp)*Math.tan(tanq);
        double result = r/(1+t);
        System.out.println("tan 60° - tan 45° / (1 + tan 60° tan 45°) : " + result);
         
        int num1;
        int num2;
         
        num1 = 45;
        num2 = 27;
        double round1 = Math.cos(num1);
        double round2 = Math.cos(num2);
        double round3 = Math.tan(num1);
        double round4 = Math.tan(num2);
        System.out.println("Rounded Value of cos 45: " + Math.round(round1));
        System.out.println("Rounded Value of cos 27: " + Math.round(round2));
        System.out.println("Rounded Value of tan 45: " + Math.round(round3));
        System.out.println("Rounded Value of tan 27: " + Math.round(round4));
         
        int num;
        num = 27;
        double exp1;
        double exp2;
        double exp3;
         
        double round5 = Math.cos(num);
        exp1 = Math.abs(8*round5);
        exp2 = Math.pow((Math.pow(7, 4)+ 8*6*7*5), 1.0/4.0);
        exp3 = Math.pow((Math.pow(5, 2)- Math.pow(3,2)), 1.0/8.0);
        double result1 = exp1*(exp2/exp3);
        System.out.println("The value of given equation is: " + result1);
        
        System.out.println("******** Random Class ********");
        
        Random rom = new Random();
        int r1 = rom.nextInt(500);
        int r2 = rom.nextInt(500);
        int r3 = rom.nextInt(500);
        int r4 = rom.nextInt(500);
         
        double r5 = r1*r1;
        double r6 = r2*r2;
        double r7 = r3*r3;
        double r8 = r4*r4;
        
        System.out.println("4 pseudo-random integer values between 0 (inclusive) and 500 \n" +
"(exclusive)");
        System.out.println("First random integer value is: " + r1 + " " + "Square of " + r1 +" is: " + r5);
        System.out.println("Second random integer value is: " + r2 + " " + "Square of " + r2 +" is: " + r6);
        System.out.println("Third random integer value is: " + r3 + " " + "Square of " + r3 +" is: " + r7);
        System.out.println("Fourth random integer value is: " + r4 + " " + "Square of " + r4 +" is: " + r8);
        
        
        int r9 = rom.nextInt();
        int r10 = rom.nextInt();
        int r11 = rom.nextInt();
        
        System.out.println("3 pseudo-random integer values without seed value and bounds");
        System.out.println("Fifth random integer value is: " + r9);
        System.out.println("Sixth random integer value is: " + r10);
        System.out.println("Seventh random integer value is: " + r11);
        
        System.out.println("Different random numbers are assigned and different results are executed for each run");
        
        
        rom.setSeed(20);
        int p1 = rom.nextInt(500);
        int p2 = rom.nextInt(500);
        int p3 = rom.nextInt(500);
        int p4 = rom.nextInt(500);
         
        double p5 = p1*p1;
        double p6 = p2*p2;
        double p7 = p3*p3;
        double p8 = p4*p4;
       
        System.out.println("4 pseudo-random integer values between 0 (inclusive) and 500 \n" +
"(exclusive)");
        System.out.println("First random integer value is: " + p1 + " " + "Square of " + p1 +" is: " + p5);
        System.out.println("Second random integer value is: " + p2 + " " + "Square of " + p2 +" is: " + p6);
        System.out.println("Third random integer value is: " + p3 + " " + "Square of " + p3 +" is: " + p7);
        System.out.println("Fourth random integer value is: " + p4 + " " + "Square of " + p4 +" is: " + p8);
        
        
        int p9 = rom.nextInt();
        int p10 = rom.nextInt();
        int p11 = rom.nextInt();
        System.out.println("3 pseudo-random integer values without seed value and bounds");
        System.out.println("Fifth random integer value is: " + p9);
        System.out.println("Sixth random integer value is: " + p10);
        System.out.println("Seventh random integer value is: " + p11);
        
        System.out.println("Random values once assigned remained same for all the runs, so the results also remained same");
        
        System.out.println("Before seed value is set all the values are randomly assigned and changed for each run. But after seed value is set, the values once assigned remained same for all the runs");
         
         
    }
             
 }
