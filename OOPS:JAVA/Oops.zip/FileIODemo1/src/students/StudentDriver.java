/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package students;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author S547509
 */
public class StudentDriver {

    private static Object scan;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("studentinput.txt"));
        PrintWriter write = new PrintWriter(new File("Annadi.txt"));
       
        while(scan.hasNext()){
            String name = scan.nextLine();
            int age = scan.nextInt();
            scan.nextLine();
            String schedule = scan.nextLine();
            boolean attendance = scan.nextBoolean();
            scan.nextLine();
            String comment = scan.nextLine();
            Student s = new Student(name, age, schedule, attendance, comment);
            System.out.println(s);
            write.println(s);
            
            
            
        }
        write.close();
  
        // TODO code application logic here
    }
    
}
