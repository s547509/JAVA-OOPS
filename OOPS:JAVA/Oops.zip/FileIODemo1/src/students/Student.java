/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package students;

/**
 *
 * @author S547509
 */
public class Student {
    private String name;
    private int age;
    private String schedule;
    private boolean attendence;
    private String comment;

    public Student(String name, int age, String schedule, boolean attendence, String comment) {
        this.name = name;
        this.age = age;
        this.schedule = schedule;
        this.attendence = attendence;
        this.comment = comment;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getSchedule() {
        return schedule;
    }

    public boolean isAttendence() {
        return attendence;
    }

    public String getComment() {
        return comment;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public void setAttendence(boolean attendence) {
        this.attendence = attendence;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @Override
    public String toString() {
        return "student{" + "name=" + name + ", age=" + age + ", schedule=" + schedule + ", attendence=" + attendence + ", comment=" + comment + '}';
    }
    
    
}
