/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animals;

/**
 *
 * @author S547509
 */
public class Animal {

    private String name;
    private double weight;
    private boolean amphibian;
    

    public Animal(String name, double weight, boolean amphibian) {
        this.name = "snake";
        this.weight = Math.abs(-0.2);
        this.amphibian = true;
        
    }
    
    public Animal(String name, double weight) {
        this.name = name;
        this.weight = weight;
        
             
    }

    public Animal(String name) {
        this.name = name;
    }

    public Animal() {
        this.name = "Pullarao";
    }
    
    
    
    
    public String getName()
    {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    public boolean isAmphibian() {
        return amphibian;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setAmphibian(boolean amphibian) {
        this.amphibian = amphibian;
        
        
    }

    @Override
    public String toString() {
        return "Animal{" + "name=" + name + "\n" + ", weight=" + weight + ", amphibian=" + amphibian + '}';
    }
    
  
    
}
