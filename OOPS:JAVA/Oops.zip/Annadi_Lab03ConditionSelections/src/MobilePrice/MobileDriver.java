/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package MobilePrice;

import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class MobileDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean checkError = false;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter User Details: ");
        System.out.print("-> Select the provider's name AT&T, T-Mobile, Verizon: ");
        String providerName = scan.next();
        System.out.print("-> How many number of users?");
        int numOfUsers = scan.nextInt();
        System.out.println("-> Are you a member of the Mobile Alliance?");
        boolean isMemberOfMobileAlliance = scan.nextBoolean();
        System.out.println("-> Are you a first time user? ");
        char isFirstTimeUser = scan.next().charAt(0);
        System.out.println("-> Do you have coupon? ");
        String hasCoupon = scan.next();
        ProviderCalculator objx = new ProviderCalculator(providerName,numOfUsers,
                isMemberOfMobileAlliance,isFirstTimeUser,hasCoupon);
        
        if(objx.checkProviderName() != true){
            System.out.println("The provider’s name " + providerName + 
                    " does not match the providers’ list");   
        }
        
       
        if(numOfUsers==0){
            System.out.println("The number of users should not be zero");
            checkError = true;
        }
        
        
        if(numOfUsers>5){
            System.out.println("The number of users should be between 3 and 5.");
            checkError = true;
            
            
        }
        if(isMemberOfMobileAlliance && (isFirstTimeUser=='Y') || 
                ((isFirstTimeUser == 'Y')&&(hasCoupon.equals("Yes"))) || 
                (isMemberOfMobileAlliance && (hasCoupon.equals("Yes")))){
            System.out.println("User can only use one discount, (1)  Member of the Mobile Alliance, (2) First Time User, or (3) has a coupon at a time.\n"+"You are required to choose only one option: (1), (2), or (3)");
            checkError = true;
        
        }
         
        if(checkError){
            System.out.println("Please try again");
        }
        else{
            System.out.println(objx.toString());
            System.out.println("++++ Receipt ++++");
            System.out.println(objx.printReceipt());
        }
    }
    
}
