/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MobilePrice;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class ProviderCalculator {
    private String providerName;
    private int numOfUsers;
    private Boolean isMemberOfMobileAlliance;
    private char isFirstTimeUser;
    private String hasCoupon;
    private double COUPON = 5.0;
    private double SALETAXES = 7.50;
    
    /**
     * Parameterized Constructor for ProvideCalculator Class
     * @param providerName is for provider name
     * @param numOfUsers is for number of users
     * @param isMemberOfMobileAlliance is to check if it is member of mobile alliance 
     * @param isFirstTimeUser is to check if it is first time user
     * @param hasCoupon is to check if it has coupon
     */

    public ProviderCalculator(String providerName, int numOfUsers, boolean isMemberOfMobileAlliance, 
            char isFirstTimeUser, String hasCoupon){
        this.providerName = providerName;
        this.numOfUsers = numOfUsers;
        this.isMemberOfMobileAlliance = isMemberOfMobileAlliance;
        this.isFirstTimeUser = isFirstTimeUser;
        this.hasCoupon = hasCoupon;
    }
    
    /**
     * @return's Returns the providerName of ProviderCalculator.
     */

    public String getProviderName() {
        return providerName;
    }
    
    /**
     * @return's numOfUsers.
     */

    public int getNumOfUsers() {
        return numOfUsers;
    }
    
    /**
     * @return's the Boolean value for isMemberOfMobileAlliance of ProviderCalculator.
     */

    public Boolean getIsMemberOfMobileAlliance() {
        return isMemberOfMobileAlliance;
    }
    
    /**
     * @return's the isFirstTimeUser of ProviderCalculator.
     */

    public char getIsFirstTimeUser() {
        return isFirstTimeUser;
    }
    
    /**
     * @return's the hasCoupon of hasCoupon.
     */

    public String getHasCoupon() {
        return hasCoupon;
    }
    
    /**
     * @return's the hasCoupon of COUPON.
     */
    
    public double getCOUPON() {
        return COUPON;
    }
    
    /**
     * @return's the SALETAXES of SALETAXES.
     */
    
    public double getSALETAXES() {
        return SALETAXES;
    }
    
    /**
     * @param providerName sets The providerName of ProviderCalculator.
     */

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }
    
    /**
     * @param numOfUsers sets The numOfUsers of ProviderCalculator.
     */

    public void setNumOfUsers(int numOfUsers) {
        this.numOfUsers = numOfUsers;
    }
    
    /**
     * @param isMemberOfMobileAlliance sets the isMemberOfMobileAlliance of ProviderCalculator.
     */

    public void setIsMemberOfMobileAlliance(Boolean isMemberOfMobileAlliance) {
        this.isMemberOfMobileAlliance = isMemberOfMobileAlliance;
    }
    
    /**
     * @param isFirstTimeUser sets the isFirstTimeUser of ProviderCalculator.
     */

    public void setIsFirstTimeUser(char isFirstTimeUser) {
        this.isFirstTimeUser = isFirstTimeUser;
    }
    
    /**
     * @param hasCoupon sets the hasCoupon of ProviderCalculator.
     */

    public void setHasCoupon(String hasCoupon) {
        this.hasCoupon = hasCoupon;
    }
    
    /**
     * @param COUPON sets the COUPON value of ProviderCalculator.
     */

    public void setCOUPON(double COUPON) {
        this.COUPON = COUPON;
    }
    
    /**
     * @param SALETAXES sets the SALETAXES value of ProviderCalculator.
     */

    public void setSALETAXES(double SALETAXES) {
        this.SALETAXES = SALETAXES;
    }
    
    /**
     * @return's string
     */

    @Override
    public String toString() {
        return "ProviderCalculator{" + "providerName=" + providerName + ", numOfUsers=" + numOfUsers + ", isMemberOfMobileAlliance=" + isMemberOfMobileAlliance + ", isFirstTimeUser=" + isFirstTimeUser + ", hasCoupon=" + hasCoupon + ", COUPON=" + COUPON + ", SALETAXES=" + SALETAXES + '}';
    }
    
    /**
     * to check Provider Name
     *
     * @return's boolean, Name Correct
     */
    
    public boolean checkProviderName(){
        boolean nameCorrect = false;
        switch(providerName){
            case "AT&T":
                nameCorrect = true;
                break;
            case "T-MOBILE":
                nameCorrect = true;
                break;
            case "VERIZON":
                nameCorrect = true;
                break;
            default:
                nameCorrect = false;       
                
        }
        return nameCorrect;
    }
    
    /**
     * to check Provider Price
     *
     * @return's double, Price
     */
    
    double priceValue;
    public double calcProviderPrice(){
        if(providerName.equalsIgnoreCase("AT&T")){
            if(numOfUsers == 1){
                priceValue = 30.99;
            } else if (numOfUsers == 2){
                priceValue = 52.99;
            } else if (numOfUsers >= 3 && numOfUsers <= 5){
                priceValue = 20.99;
            }
        } else if (providerName.equalsIgnoreCase("T-Mobile")) {
            if(numOfUsers == 1){
                priceValue = 39.99;
            } else if (numOfUsers == 2){
                priceValue = 70.99;
            } else if (numOfUsers >= 3 && numOfUsers <= 5){
                priceValue = 29.99;
            }
        } else if (providerName.equalsIgnoreCase("VERIZON")){
            if(numOfUsers == 1){
                priceValue = 43.99;
            } else if (numOfUsers == 2){
                priceValue = 75.99;
            } else if (numOfUsers >= 3 && numOfUsers <= 5){
                priceValue = 33.99;
            }
        }
        return priceValue;
    }
    
    /**
     * to check Membership Discount
     *
     * @return's double, Membership Discount
     */
    
    
    public double calcMembershipDiscount(){
        double md = 0.0;
        if(isMemberOfMobileAlliance == true && checkProviderName()){
            if(numOfUsers == 1){
                md = (calcProviderPrice() * 7.5) / 100;
            } else if (numOfUsers == 2){
                md = (calcProviderPrice() * 6.5) / 100;
            } else if (numOfUsers >= 3 && numOfUsers <=5){
                md = (calcProviderPrice() * 8.5) / 100;
            }
            return md;
        }else {
            return 0.0;
        }
    }
    
    /**
     * to check First Time User Discount
     *
     * @return's double, First Time User Discount
     */
    
    double firstTimeUserDiscount;
    public double calcFirstTimeUserDiscount(){
        if(isFirstTimeUser ==  'Y'){
            if(numOfUsers == 1){
                firstTimeUserDiscount = calcProviderPrice() * 0.1;
            } else if (numOfUsers == 2){
                firstTimeUserDiscount = calcProviderPrice() * 0.05;
            } else if (numOfUsers >= 3 && numOfUsers <=5){
                firstTimeUserDiscount = calcProviderPrice() * 0.04;
            }
            return firstTimeUserDiscount;
        }else {
            return 0.0;
        }
    }
    
    /**
     * to check Coupon Discount
     *
     * @return's double, Coupon Discount
     */
    
    double cd;
    public double calcCouponDiscount(){
        if(hasCoupon.equals("Yes")){
            cd = COUPON;
            return COUPON;
        } else {
            return 0.0;
        }
    }
    
    /**
     * to check Total Price
     *
     * @return's double, Total Price
     */
    
    public double totalPrice(){
        double totalPrice = calcProviderPrice() - calcMembershipDiscount() -
                calcFirstTimeUserDiscount() - calcCouponDiscount();
        
        return (double) Math.round(totalPrice * 100)/100;
    }
    
    /**
     * to check Total Price with Sales Tax
     *
     * @return's double, total price with sales tax
     */
    
    
    public double totalPriceWithSalesTax() {
        double totalPriceWithSalesTax = totalPrice() + (0.075*totalPrice());
        return (double) Math.round(totalPriceWithSalesTax * 100)/100;
    }
        
    /**
     * Prints the Receipt
     * 
     * @return's Returns the String of the data
     */
    
   
    public String printReceipt(){
        return "Mobile Charges for " + numOfUsers + " user using " + providerName +
                " as provider is: $" + calcProviderPrice() + "\n" +
                "Member of the Mobile Alliance: $" + calcMembershipDiscount() + "\n" +
                "First Time user discount: $" + calcFirstTimeUserDiscount() + "\n" +
                "Coupon Discount: $" + calcCouponDiscount() + "\n" +
                "Charges After applying Discount: $" + totalPrice() + "\n" +
                "Total Price with Tax: $" + totalPriceWithSalesTax();
    }
}
