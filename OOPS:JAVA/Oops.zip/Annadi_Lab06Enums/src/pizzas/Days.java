/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzas;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Days {
    
    /*This class provides methods to know the order day and order discounts.*/
    
        private Days() {
    }
        
    /**
     * 
     * @return OrderDayOfWeek for the order
     */

    static String getOrderDayOfWeek(String orderDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate transactionTime = LocalDate.parse(orderDate, formatter);
        return transactionTime.getDayOfWeek().toString();
    }
    
    /**
     * 
     * @return DiscountDay for the order
     */

    static boolean isDiscountDay(String orderDate) {
        return "SATURDAY".equals(getOrderDayOfWeek(orderDate))
                || "SUNDAY".equals(getOrderDayOfWeek(orderDate));
    }
    
}
