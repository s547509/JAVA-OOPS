/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzas;

import pizzas.Sides.Cheese;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Order {
        private PizzaTypes pizzasName;
    private String pizzasSize;
    private int quantity;
    private Sauces sauce;
    private Sides side;
    private String sideSize;
    private Drinks drink;
    private Cheese cheese;
    private Desserts dessert;
    private Double cost;
    
    //Parameterized constructor
    /**
     * 
     * @param pizzasName is the name of pizza
     * @param pizzasSize is the size of pizza
     * @param quantity is the quantity of pizza
     * @param sauce is the sauce of pizza
     * @param side is the side for pizza
     * @param sideSize is the side size of pizza
     * @param drink is the drinks for order
     * @param cheese is the cheese for order
     * @param dessert is the dessert for order
     */
    
    public Order(PizzaTypes pizzasName, String pizzasSize, int quantity,
            Sauces sauce, Sides side, String sideSize, Drinks drink, Cheese cheese,
            Desserts dessert) {
        this.pizzasName = pizzasName;
        this.pizzasSize = pizzasSize;
        this.quantity = quantity;
        this.sauce = sauce;
        this.side = side;
        this.sideSize = sideSize;
        this.drink = drink;
        this.cheese = cheese;
        this.dessert = dessert;
    }
    
    /**
     * 
     * @return PizzasName for the order
     */
    
    public PizzaTypes getPizzasName() {
        return pizzasName;
    }
    
    /**
     * 
     * @return PizzasSize for the order
     */
    
    public String getPizzasSize() {
        return pizzasSize;
    }
    
    /**
     * 
     * @return Quantity for the order
     */
    
    public int getQuantity() {
        return quantity;
    }
    
    /**
     * 
     * @return Sauce for the order
     */
    
    public Sauces getSauce() {
        return sauce;
    }
    
    /**
     * 
     * @return Side for the order
     */
    
    public Sides getSide() {
        return side;
    }
    
    /**
     * 
     * @return SideSize for the order
     */
    
    public String getSideSize() {
        return sideSize;
    }
    
    /**
     * 
     * @return Drink for the order
     */
    
    public Drinks getDrink() {
        return drink;
    }
    
    /**
     * 
     * @return Cheese for the order
     */
    
    public Cheese getCheese() {
        return cheese;
    }
    
    /**
     * 
     * @return Dessert for the order
     */
    
    public Desserts getDessert() {
        return dessert;
    }
    
    /**
     * 
     * @return Cost for the order
     */
    
    public Double getCost() {
        return cost;
    }
    
    /**
     * 
     * @return DessertCost for the order
     */
    
    private double calcDessertCost() {
        return dessert.getDessertPrice();
    }
    
    /**
     * 
     * @return SauceCost for the order
     */
    
    private double calcSauceCost() {
        return sauce.getPriceOfSauce();
    }
    
    /**
     * 
     * @return CheeseCost for the order
     */
    
    private double calcCheeseCost() {
        return cheese.getCheesePrice();
    }
    
    /**
     * 
     * @return DrinkCost for the order
     */
    
    private double calcDrinkCost() {
        return drink.getDrinkPrice();
    }
    
    /**
     * 
     * @return SideCost for the order
     */
    
     private double calcSideCost() {
        switch (sideSize.toLowerCase()) {
            case "small":
                return side.getSmallSidesPrice();
            case "family":
                return side.getFamilySidesPrice();
            case "party":
                return side.getPartySidesPrice();
        }
        return 0.0;
    }
     
    /**
     * 
     * @return PizzasCost for the order
     */
     
    public double calcPizzasCost() {
        switch (pizzasSize.toUpperCase()) {
            case "SMALL":
                return pizzasName.getSmallPizzaPrice() * quantity;
            case "MEDIUM":
                return pizzasName.getMediumPizzaPrice() * quantity;
            case "LARGE":
                return pizzasName.getLargePizzaPrice() * quantity;
        }
        return 0.0;
    }
    
    /**
     * 
     * @return Discount for the order
     */
    
    public double calcDiscount(String orderDate) {
        if (Days.isDiscountDay(orderDate)) {
            if (pizzasName.name().equals("HANDTOSSED_PIZZA")) {
                return calcPizzasCost()/ 2;
            }}
        return 0.0;
    }
    
    /**
     * 
     * @return TotalCost for the order
     */
    
    public double getTotalCost(String orderDate) {
        cost = calcDessertCost() + calcSauceCost()+calcDrinkCost()+calcSideCost()+
                + calcCheeseCost() + calcPizzasCost();  
        return cost;
    }
    
    /**
     * 
     * @return returns pizza details for the order
     */
    
    @Override
    public String toString() {
        return "PIZZA TYPE: " + pizzasName.toString().replace("_", " ") + "\n"
                + "PIZZA SIZE: " + pizzasSize.toUpperCase() + "\n"
                + "QUANTITY: " + quantity + "\n"
                + "SAUCE: " + sauce.toString().replace("_", " ") + "\n"
                + "SIDES: " + side.toString().replace("_", " ") + " (" + sideSize.toUpperCase() + ")\n"
                + "CHEESE: "+cheese.toString().replace("_", " ")+"\n"
                + "DRINKS: " + drink.toString().replace("_", " ") + "\n"
                + "DESSERTS: " + dessert.toString().replace("_", " ") + "\n"
                + "COST: " + (String.format("%.2f", (Math.round(getCost() * 100)/100.0))) + "\n";
    }
}

    

