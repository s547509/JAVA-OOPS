/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pizzas;

/**
 *
 * @author Rohith Reddy Annadi
 */
public enum Sauces {
    PESTO(0.10),TOMATO(0.12),BECHAMEL(0.20),BBQ(0.30),HUMMUS(0.15),MARINARA(0.20),TAPENADE(0.12),PUMPKIN_PIZZA_SAUCE(0.20),NO_SAUCE(0.00);
    private double priceOfSauce;

    private Sauces(double priceOfSauce) {
        this.priceOfSauce = priceOfSauce;
    }

    public double getPriceOfSauce() {
        return priceOfSauce;
    }
    
    
}
