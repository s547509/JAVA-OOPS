/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pizzas;

/**
 *
 * @author Rohith Reddy Annadi
 */
public enum PizzaTypes {
    HANDTOSSED_PIZZA(8.50,11.50,14.50), PAN_PIZZA(6.50,9.50,12.50);
    private double smallPizzaPrice;
    private double mediumPizzaPrice;
    private double largePizzaPrice;

    private PizzaTypes(double smallPizzaPrice, double mediumPizzaPrice, double largePizzaPrice) {
        this.smallPizzaPrice = smallPizzaPrice;
        this.mediumPizzaPrice = mediumPizzaPrice;
        this.largePizzaPrice = largePizzaPrice;
    }

    public double getSmallPizzaPrice() {
        return smallPizzaPrice;
    }

    public double getMediumPizzaPrice() {
        return mediumPizzaPrice;
    }

    public double getLargePizzaPrice() {
        return largePizzaPrice;
    }
    
    
}
