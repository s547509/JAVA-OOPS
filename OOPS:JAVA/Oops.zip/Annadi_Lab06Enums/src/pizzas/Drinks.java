/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pizzas;

/**
 *
 * @author Rohith Reddy Annadi
 */
public enum Drinks {
    FOUNTAIN_SODA_20_OZ(1.99), RED_BULL(5.29), IZZE_SPARKLING_JUICE(3.79),
    FRESH_BREWED_ICED_TEA(3.99), WATER(0.00);
    public double drinkPrice;

    private Drinks(double drinkPrice) {
        this.drinkPrice = drinkPrice;
    }
    
    /**
     * 
     * @return DrinkPrice for the order
     */

    public double getDrinkPrice() {
        return drinkPrice;
    }
    
    
}
