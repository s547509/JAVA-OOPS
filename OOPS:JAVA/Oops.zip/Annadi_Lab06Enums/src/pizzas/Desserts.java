/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pizzas;

/**
 *
 * @author Rohith Reddy Annadi
 */
public enum Desserts {
    
    CHOCOLATE_FUDGE_CAKE(10.99), CHEESECAKE_BITES(12.49), DESSERT_NACHOS(9.49),
    LOADED_ICE_CREAM(5.49), NO_DESSERTS(0.00);

    public double dessertPrice;

    private Desserts(double dessertPrice) {
        this.dessertPrice = dessertPrice;
    }
    
    /**
     * 
     * @return DessertPrice for the order
     */
     

    public double getDessertPrice() {
        return dessertPrice;
    }
    
    
    
}
