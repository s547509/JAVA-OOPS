/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pizzas;

/**
 *
 * @author Rohith Reddy Annadi
 */
public enum Sides {
    GARLIC_CHEESEBREAD(5.99, 20.99, 30.99), CHEFSALAD(3.99, 15.99, 25.99),
    RANCH_STIX(2.99, 6.99, 13.99), RANCH_POTATO_WEDGES(3.99, 11.99, 22.99),
    MASHED_POTATOES(6.99, 15.99, 30.99), RANCH_CHIPS(4.99, 16.99, 35.99),
    PARMESAN_BROCCOLI(3.99, 8.99, 20.99), ONION_RINGS(1.99, 5.49, 19.49),
    NO_SIDES(0.00, 0.00, 0.00);

    private double smallSidesPrice;
    private double familySidesPrice;
    private double partySidesPrice;

    private Sides(double smallSidesPrice, double familySidesPrice, double partySidesPrice) {
        this.smallSidesPrice = smallSidesPrice;
        this.familySidesPrice = familySidesPrice;
        this.partySidesPrice = partySidesPrice;
    }

    public double getSmallSidesPrice() {
        return smallSidesPrice;
    }

    public double getFamilySidesPrice() {
        return familySidesPrice;
    }

    public double getPartySidesPrice() {
        return partySidesPrice;
    }
    
     public enum Cheese{
        AMERICAN_CHEESE(0.10), CHEDDAR_CHEESE(0.12), CHEDDAR_JACK_CHEESE(0.20),
        PEPPER_JACK_CHEESE(0.30), QUESO_CHEESE(0.15), SWISS_CHEESE(0.20),
        BLUE_CHEESE(0.12), RANCH(0.20), NO_CHEESE(0.0);

        public double getCheesePrice() {
            return CheesePrice;
        }

        public double CheesePrice;

        private Cheese(double CheesePrice) {
            this.CheesePrice = CheesePrice;
        }
    }
}
