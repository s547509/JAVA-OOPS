/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzas;

import java.util.ArrayList;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class OrdersSummary {
   private ArrayList<Order> orders = new ArrayList<>();
   
   public OrdersSummary() {
    }
   
   public ArrayList<Order> getOrders() {
        return orders;
    }
   
   public void addAOrder(Order or) {
        orders.add(or);
    }
   
    /**
     * 
     * @return returns TotalCostOfAllOrders for the order
     */
   
    public double calcTotalCostOfAllOrders(String orderDate) {
        double orderCost = 0.0;
        for (Order r : orders) {
            orderCost += r.getTotalCost(orderDate);
        }
        return orderCost;
    }
    
    /**
     * 
     * @return returns TotalBillWithTax for the order
     */

    public double calcTotalBillWithTax(String orderDate) {
        double orderCost = 0.0;
        for (Order r : orders) {
            orderCost += r.getTotalCost(orderDate) - r.calcDiscount(orderDate);
        }
        return orderCost + (orderCost * (8.6 / 100));
    }
    
    /**
     * 
     * @return returns the receipt of the order
     */

    public String printReceipt(String orderDate) {
        String printReceipt = "**************  " + orderDate + ", " + Days.getOrderDayOfWeek(orderDate) + "  ***************\n";
        double discout = 0.0;
        double tax = 0.0;
        for (Order r : orders) {
            discout += r.calcDiscount(orderDate);
            tax += (r.getTotalCost(orderDate) - discout) * (8.6 / 100);
            printReceipt += r.toString();
        }
        printReceipt += "-----------------------------------------------------\n"
                + "		Order Total :		$"
                + (String.format("%.2f", (Math.round(calcTotalCostOfAllOrders(orderDate) * 100) / 100.0))) + "\n"
                + "		Discount@50 :		"
                + "$" + (String.format("%.2f", (Math.round(discout * 100) / 100.0))) + "\n"
                + "		Tax@8.6 :		"
                + "$" + (String.format("%.2f", (Math.round(tax * 100) / 100.0))) + "\n"
                + "		Total Amount with tax : $"
                + (String.format("%.2f", (Math.round(calcTotalBillWithTax(orderDate) * 100) / 100.0))) + "\n"
                + "-----------------------------------------------------";

        return printReceipt;
    
}}

