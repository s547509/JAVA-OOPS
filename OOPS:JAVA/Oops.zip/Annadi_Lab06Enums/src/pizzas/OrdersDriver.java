/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import pizzas.Sides.Cheese;

/**
 *
 * @author Rohith Reddy Annadi 
 */
public class OrdersDriver {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("input.txt"));
        System.out.println("*****************************************************");
        System.out.println("*********************** Pizza Hut ******************");
        System.out.println("*****************************************************");

        while (scan.hasNext()) {    
            OrdersSummary ordrSmry = new OrdersSummary();
            String odDt = scan.nextLine();
            Days.getOrderDayOfWeek(odDt);
            String pzNm = scan.nextLine();
            PizzaTypes pzaTypzaStg = PizzaTypes.valueOf(pzNm.toUpperCase().replaceAll(" ", "_"));
            String pzaStg = scan.next();
            int qnty = scan.nextInt();
            scan.nextLine();
            String sau = scan.nextLine();
            Sauces suc = Sauces.valueOf(sau.toUpperCase().replaceAll(" ", "_"));
            String sides = "";
            do {
                sides = sides + scan.next() + " ";
            } while (!(scan.hasNext("-")));
            scan.next();
            Sides sd = Sides.valueOf(sides.toUpperCase().trim().replace(" ", "_"));
            String sS = scan.next();
            String chs = (scan.next() + scan.nextLine()).toUpperCase().replaceAll(" ", "_");
            Cheese c = Cheese.valueOf(chs);
            String dr = scan.nextLine().toUpperCase().replaceAll(" ", "_");
            Drinks drin = Drinks.valueOf(dr);
            String st = scan.nextLine().toUpperCase().trim().replace(" ", "_");
            Desserts drt = Desserts.valueOf(st);
            
            Order o = new Order(pzaTypzaStg, pzaStg, qnty, suc,
                    sd, sS, drin, c, drt);
            ordrSmry.addAOrder(o);
            System.out.println(ordrSmry.printReceipt(odDt));
        }
    }
    

}
