/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package scannerdemo;

import java.util.Scanner;

/**
 *
 * @author S547509
 */
public class ScannerDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the name: ");
        String name = scan.nextLine();
        System.out.println("Enter the age: ");
        int age = scan.nextInt();
        System.out.println("Enter the salary ");
        double salary = scan.nextDouble();
        
        System.out.println(name + "-" + age + "-" + salary);
        
        String str = new String("Hi");
        String str1 = "Hi";
        System.out.println(str==str1);
        
        
    }
    
}
