/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking;

/**
 * Class: 44542-06 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 10/29/2022
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Customer {

    private String dob; //date of birth of customer
    private String firstName;
    private String lastName;

    /**
     * constructor parameters
     *
     * @param dob is the date of birth of the customer 
     * @param firstName first name of the customer
     * @param lastName last name of the customer
     */
    public Customer(String dob, String firstName, String lastName) {
        this.dob = dob;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * using Getter for getDob
     *
     * @return date of birth of the customer
     */
    public String getDob() {
        return dob;
    }

    /**
     * using Getter for getFirstName
     *
     * @return first Name of the customer
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * using Getter for getLastName
     *
     * @return last Name of the customer
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * using Setter for setDob
     *
     * @param dob date of birth of the customer
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     * using Setter for setFirstName
     *
     * @param firstName first name of the customer
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * using Setter for setLastName
     *
     * @param lastName last name of the customer
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * using toString() method
     */
    
    @Override
    public String toString() {
        return "Name: " + lastName + ", " + firstName + "\n" + "Date of Birth: " + dob;
    }

}

