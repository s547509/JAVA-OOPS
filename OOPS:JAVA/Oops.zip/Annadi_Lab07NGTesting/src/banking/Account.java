/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking;

import java.util.ArrayList;

/**
 * Class: 44542-06 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 10/29/2022
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Account {

    private long accountNumber;
    private Customer customer;
    private double balance;
    private ArrayList<Transaction> transactions;
    private boolean hasLimitedWithdrawals;
    private static final double SAVING_INTEREST = 5.80;

    /**
     * constructor with parameters
     *
     * @param accountNumber account number
     * @param customer object of customer
     * @param hasLimitedWithdrawals limit withdrawals
     */
    public Account(long accountNumber, Customer customer, boolean hasLimitedWithdrawals) {
        this.accountNumber = accountNumber;
        this.customer = customer;
        this.hasLimitedWithdrawals = hasLimitedWithdrawals;
        transactions = new ArrayList<Transaction>();
    }

    /**
     * using getter for getAccountNumber
     *
     * @return account number of the customer
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * using getter for getCustomer
     *
     * @return customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * using getter for getBalance
     *
     * @return balance in the account
     */
    public double getBalance() {
        return balance;
    }

    /**
     * using getter for Transactions
     *
     * @return transactions
     */
    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    /**
     * using getter for hasLimitedWithdrawals
     *
     * @return hasLimitedWithdrawals
     */
    public boolean isHasLimitedWithdrawals() {
        return hasLimitedWithdrawals;
    }

    /**
     * using getter for savings_interest
     *
     * @return SAVING_INTEREST
     */
    public static double getSAVING_INTEREST() {
        return SAVING_INTEREST;
    }

    /**
     * using generateStatement method
     *
     * @return string
     */
    public String generateStatement() {
        String statement = "";
        if (hasLimitedWithdrawals) {
            statement = statement + customer.toString() + "\n" + "Account Number: " + accountNumber + "\n" + "Account Information:-	Interest Rate: 5.80%" + "\n" + "Transaction Limit for withdrawal: 7 Transactions" + "\n" + "-------------------------------------------------------------------------------\n";
        } else {
            statement = statement + customer.toString() + "\n" + "Account Number: " + accountNumber + "\n" + "Account Information:-	Interest Rate: 5.80%" + "\n" + "Transaction Limit for withdrawal: No Limit" + "\n" + "-------------------------------------------------------------------------------\n";
        }

        statement = statement + "Transaction Type    Transaction Time         Amount          Additional Charges       Status    " + "\n";
        for (int i = 0; i < transactions.size(); i++) {
            statement = statement + String.format("%-20s%-25s%-16.2f%-25.2f%-10s\n", transactions.get(i).getTransactionType(), transactions.get(i).getTransactionTime(), transactions.get(i).getAmount(), transactions.get(i).getAdditionalCharges(), transactions.get(i).getStatus());

        }

        return statement;
    }

    /**
     * using getNoofWithdrawals method
     *
     * @return number of withdrawals
     */
    public int getNoofWithdrawals() {
        int record = 0;
        for (Transaction trans : transactions) {
            if (trans.getTransactionType().equals("WITHDRAW")) {
                if (trans.getTransactionTime().getMonthValue() == 3) {
                    record++;
                }
            }
        }
        return record;
    }

    /**
     * @param transaction transaction
     * @return status
     */
    public String makeTransaction(Transaction transaction) {
        String str = "";
        int count = 0;
        int size = transactions.size();
        for (int i = 0; i < size; i++) {
            if (transaction.getTransactionType().equals("WITHDRAW")) {
                if (transactions.get(i).getTransactionTime().getMonthValue() == transaction.getTransactionTime().getMonthValue()) {
                    count++;
                }
            }
        }

        if (transaction.getTransactionType().equals("WITHDRAW")) {
            if (balance < transaction.getAmount()) {
                transaction.setAdditionalCharges(0);
                transaction.setStatus("FAILED");
                str = "Insufficient Balance";
            } else {
                if (hasLimitedWithdrawals) {
                    if (count > 7) {
                        transaction.setAdditionalCharges(0);
                        transaction.setStatus("FAILED");
                        str = "MaxTransactions";
                    } else {
                        transaction.setAdditionalCharges(0);
                        transaction.setStatus("SUCCESS");
                        str = "Transaction Successful";
                        balance = balance - transaction.getAmount();
                        balance = (Math.round(balance * 100)) / 100.0;
                    }
                } else {
                    if (count > 6) {
                        double addCharges = (transaction.getAmount() * (SAVING_INTEREST + 1)) / 100;
                        addCharges = (Math.round(addCharges) * 100) / 100.0;
                        transaction.setAdditionalCharges(addCharges);
                        transaction.setStatus("SUCCESS");
                        str = "Transaction Successful";
                        balance = balance - transaction.getAmount() - addCharges;
                        balance = (Math.round(balance * 100)) / 100.0;
                    } else {
                        transaction.setAdditionalCharges(0);
                        transaction.setStatus("SUCCESS");
                        str = "Transaction Successful";
                        balance = balance - transaction.getAmount();
                        balance = (Math.round(balance * 100)) / 100.0;
                    }

                }
            }
        } else if (transaction.getTransactionType().equals("ONLINEPURCHASE")) {
            if (balance < transaction.getAmount()) {
                transaction.setAdditionalCharges(0);
                transaction.setStatus("FAILED");
                str = "Insufficient Balance";
            } else {
                double addCharges = 1.99;
                //addCharges =(Math.round(addCharges)*100)/100.0;
                transaction.setAdditionalCharges(addCharges);
                transaction.setStatus("SUCCESS");
                str = "Transaction Successful";
                balance = balance - transaction.getAmount() - addCharges;
                balance = (Math.round(balance * 100)) / 100.0;
            }
        } else if (transaction.getTransactionType().equals("DEPOSIT")) {
            transaction.setAdditionalCharges(0);
            transaction.setStatus("SUCCESS");
            str = "Transaction Successful";
            balance = balance + transaction.getAmount();
            balance = (Math.round(balance * 100)) / 100.0;
        }

        transactions.add(transaction);
        return str;
    }
}
