/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: 44542-06 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 10/29/2022
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class BankDriver {

    /**
     * @param args arguments
     * @throws java.io.FileNotFoundException if file not found it generate file
     * not found exemption
     */
    // TODO code application logic here
    public static void main(String[] args) throws FileNotFoundException {
        int flag = 0;
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-M-d H:m:s");
        ArrayList<Account> accounts = new ArrayList<>();
        Scanner sc = new Scanner(new File("input.txt"));
        while (sc.hasNext()) {
            String accountType = sc.nextLine();
            String firstname = sc.next();
            String lastname = sc.nextLine();
            String dob = sc.nextLine();
            long accountNo = sc.nextLong();
            sc.nextLine();
            boolean hasWithdrawLimit = sc.nextBoolean();
            sc.nextLine();
            Customer cust = new Customer(dob, firstname, lastname);
            Account newAccount = new Account(accountNo, cust, hasWithdrawLimit);
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the customer: " + cust.getFirstName() + " " + cust.getLastName());
            System.out.println("------------------------------------------------------------");
            String transactionType = "";
            while (!(transactionType.equals("newAccount")) && sc.hasNext()) {
                transactionType = sc.next();
                if (transactionType.equals("newAccount")) {

                } else {

                    double amount = sc.nextDouble();
                    String date1 = sc.next().trim();
                    String date2 = sc.next().trim();
                    String date = date1 + " " + date2;
                    LocalDateTime local = LocalDateTime.parse(date, dateFormat);
                    Transaction newTransaction = new Transaction(transactionType, amount, local);
                    String res = newAccount.makeTransaction(newTransaction);
                    if (res.equals("MaxTransactions")) {
                        System.out.println("Exceeded number of withdrawals transactions. Number of available withdrawals per month: 6");

                    } else if (res.equals("Insufficient Balance")) {
                        System.out.println("Insufficient funds. Available funds: " + String.format("%.2f", newAccount.getBalance()));
                    } else if (res.equals("Transaction Successful")) {
                        System.out.println("The balance after " + transactionType + " in dollars is " + String.format("%.2f", newAccount.getBalance()));
                    }
                }
            }

            accounts.add(newAccount);
        }
        System.out.println("************************************************************************");
        System.out.println("*********Invoke getNoofWithdrawals() on Account objects**********");
        System.out.println("************************************************************************");
        for (Account acc : accounts) {
            System.out.println(acc.getCustomer().getFirstName() + " made " + acc.getNoofWithdrawals() + " withdrawals in this month.");
        }

        System.out.println("***********************************************************************");
        System.out.println("****Invoke generateStatement() on all objects in accounts ArrayList****");
        System.out.println("************************************************************************");
        for (Account act : accounts) {
            System.out.print(act.generateStatement());
            System.out.println("-------------------------------------------------------------------------------");
            double interest = (act.getBalance() * act.getSAVING_INTEREST()) / 100;

            System.out.println("Current Balance: " + String.format("%.2f", act.getBalance()) + "		Interest: $" + String.format("%.2f", interest));
            System.out.println("************************************************************************");
        }
    }

}
