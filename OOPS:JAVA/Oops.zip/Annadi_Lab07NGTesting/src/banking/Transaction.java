/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking;

import java.time.LocalDateTime;

/**
 * Class: 44542-06 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 10/29/2022
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Transaction {

    private double additionalCharges;
    private double amount;
    private String status;
    private LocalDateTime transactionTime;
    private String transactionType;

    
    public Transaction(String transactionType, double amount, LocalDateTime transactionTime) {
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionTime = transactionTime;

    }

    /**
     * using Getter for getAdditionalCharges
     *
     * @return additional charges 
     */
    public double getAdditionalCharges() {
        return additionalCharges;
    }

    /**
     * using Getter for getAmount
     *
     * @return amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * using Getter for getStatus
     *
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * using Getter for getTransactionTime
     *
     * @return transaction time
     */
    public LocalDateTime getTransactionTime() {
        return transactionTime;
    }

    /**
     * using Getter for getTransactionType
     *
     * @return transaction type
     */

    public String getTransactionType() {
        return transactionType;
    }

    /**
     * using Setter for setAdditionalCharges
     *
     * @param additionalCharges additional charges
     */
    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    /**
     * using Setter for setAmount
     *
     * @param amount amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * using Setter for setStatus
     *
     * @param status status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * using Setter for transactionTime
     *
     * @param transactionTime time of the transaction
     */
    public void setTransactionTime(LocalDateTime transactionTime) {
        this.transactionTime = transactionTime;
    }

    /**
     * using Setter for transactionType
     *
     * @param transactionType type of the transaction
     */
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    /**
     * using toString() method
     */

    @Override
    public String toString() {
        return transactionType + "             " + transactionTime + "      " + String.format("%.2f", amount) + "         " + additionalCharges + "                     " + status;
    }

}
