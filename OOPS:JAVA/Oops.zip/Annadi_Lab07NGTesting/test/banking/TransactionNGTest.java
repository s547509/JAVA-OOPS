/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package banking;

import java.time.LocalDateTime;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-06 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 10/29/2022
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class TransactionNGTest {

    Transaction transact;
    LocalDateTime now = LocalDateTime.now();

    public TransactionNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        transact = new Transaction("WITHDRAWLS", 345.09, now);
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testGetAdditionalCharges() {
        System.out.println("getAdditionalCharges");
        double expResult = 0.0;
        double result = transact.getAdditionalCharges();
        assertEquals(result, expResult, 0.0);
    }

    /**
     * Test of setAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testSetAdditionalCharges() {
        System.out.println("setAdditionalCharges");
        double additionalCharges = 5.6;
        transact.setAdditionalCharges(additionalCharges);
    }

    /**
     * Test of getAmount method, of class Transaction.
     */
    @Test
    public void testGetAmount() {
        System.out.println("getAmount");
        double expResult = 345.09;
        double result = transact.getAmount();
        assertEquals(result, expResult, 0.0);
    }

    /**
     * Test of setAmount method, of class Transaction.
     */
    @Test
    public void testSetAmount() {
        System.out.println("setAmount");
        double amount = 0.0;
        transact.setAmount(amount);
    }

    /**
     * Test of getStatus method, of class Transaction.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        String expResult = null;
        String result = transact.getStatus();
        assertEquals(result, expResult);
    }

    /**
     * Test of setStatus method, of class Transaction.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");
        String status = "";
        transact.setStatus(status);
    }

    /**
     * Test of getTransactionTime method, of class Transaction.
     */
    @Test
    public void testGetTransactionTime() {
        System.out.println("getTransactionTime");
        LocalDateTime expResult = now;
        LocalDateTime result = transact.getTransactionTime();
        assertEquals(result, expResult);
    }

    /**
     * Test of setTransactionTime method, of class Transaction.
     */
    @Test
    public void testSetTransactionTime() {
        System.out.println("setTransactionTime");
        LocalDateTime transactionTime = now;
        transact.setTransactionTime(transactionTime);
    }

    /**
     * Test of getTransactionType method, of class Transaction.
     */
    @Test
    public void testGetTransactionType() {
        System.out.println("getTransactionType");
        String expResult = "WITHDRAWLS";
        String result = transact.getTransactionType();
        assertEquals(result, expResult);
    }

    /**
     * Test of setTransactionType method, of class Transaction.
     */
    @Test
    public void testSetTransactionType() {
        System.out.println("setTransactionType");
        String transactionType = "DEPOSIT";
        transact.setTransactionType(transactionType);
        }

   
}