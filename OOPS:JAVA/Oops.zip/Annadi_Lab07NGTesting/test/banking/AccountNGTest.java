/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package banking;

import java.util.*;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-06 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 10/29/2022
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class AccountNGTest {

    static Account acc;

    public AccountNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        acc = new Account(3429587739L, new Customer("09/23/1994", "Clint", "Barton"), true);
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getAccountNumber method, of class Account.
     */
    @Test
    public void testGetAccountNumber() {
        System.out.println("getAccountNumber");
        long expResult = 3429587739L;
        long result = acc.getAccountNumber();
        assertEquals(result, expResult);
    }

    /**
     * Test of getCustomer method, of class Account.
     */
    @Test
    public void testGetCustomer() {
        System.out.println("getCustomer");
        Customer expResult = new Customer("09/23/1994", "Clint", "Barton");
        Customer result = acc.getCustomer();
        assertEquals(result.toString(), expResult.toString());
    }

    /**
     * Test of getBalance method, of class Account.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        double expResult = 0.0;
        double result = acc.getBalance();
        assertEquals(result, expResult, 0.0);
    }

    /**
     * Test of getTransactions method, of class Account.
     */
    @Test
    public void testGetTransactions() {
        System.out.println("getTransactions");
        ArrayList expResult = new ArrayList();
        ArrayList result = acc.getTransactions();
        assertEquals(result.size(), expResult.size());
    }

    /**
     * Test of isHasLimitedWithdrawals method, of class Account.
     */
    @Test
    public void testIsHasLimitedWithdrawals() {
        System.out.println("isHasLimitedWithdrawals");
        boolean expResult = true;
        boolean result = acc.isHasLimitedWithdrawals();
        assertEquals(result, expResult);
    }

    /**
     * Test of getSAVING_INTEREST method, of class Account.
     */
    @Test
    public void testGetSAVING_INTEREST() {
        System.out.println("getSAVING_INTEREST");
        double expResult = 5.80;
        double result = acc.getSAVING_INTEREST();
        assertEquals(result, expResult, 0.0);
    }

}