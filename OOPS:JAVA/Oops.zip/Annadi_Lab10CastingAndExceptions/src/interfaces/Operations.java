/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;


import accounts.Transaction;
import exceptions.OverdraftLimitExceededException;

/**
 *
 * @author Rohith Reddy Annadi
 */
public interface Operations {

    static final double OVERDRAFT_LIMIT = 500.00;
    static final double SAVING_INTEREST = 5.8;

    public String generateStatement();

    public double makeTransaction(Transaction transaction) throws Exception;

}
