/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package enums;

/**
 *
 * @author Rohith Reddy Annadi
 */
public enum TransactionType {
    /**
     * Deposit type of transaction of account type
     */
    DEPOSIT,
    /**
     * OnlinePurchase Transaction type
     */
    ONLINEPURCHASE,
    /**
     * Amount Withdrawn of Transaction
     */
    WITHDRAW;

}
