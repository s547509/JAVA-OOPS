/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accounts;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Customer {

    /**
     * Customer FirstName
     */
    public String firstName;
    /**
     * Customer LastName
     */
    public String lastName;
    /**
     * Customer dob
     */
    public String dob;

    /**
     * Customer object using Constructor
     *
     * @param firstName
     * @param lastName
     * @param dob
     */
    public Customer(String firstName, String lastName, String dob) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
    }

    /**
     * Getter method for Customer FirstName
     *
     * @return
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * getter method for Customer LastName
     *
     * @return
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * getter method for Customer DOB
     *
     * @return
     */
    public String getDob() {
        return dob;
    }

    /**
     * setter method for Customer FirstName
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * setter method for Customer LastName
     *
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * setter method for Customer DOB
     *
     * @param dob
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    @Override
    public String toString() {
        return "Name: " + lastName + ", " + firstName + "\nDate of Birth: " + dob;
    }

}
