/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accounts;


import enums.TransactionType;
import exceptions.InsufficentFundsException;
import exceptions.MaxTransactionsException;
import java.time.LocalDateTime;
import java.time.Month;


/**
 *
 * @author Rohith Reddy Annadi
 */
public class SavingsAccount extends Account {

    /**
     * Boolean Value which stores the NumberofLimiteddrawals
     */
    public boolean hasLimitedWithdrawals;

    /**
     * Constructor for SavingsAccount
     *
     * @param customer
     * @param accountNumber
     * @param hasLimitedWithdrawals
     */
    public SavingsAccount(Customer customer, long accountNumber, boolean hasLimitedWithdrawals) {
        super(customer, accountNumber);
        this.hasLimitedWithdrawals = hasLimitedWithdrawals;
    }

    @Override
    public String generateStatement() {
        String limit;
        if (hasLimitedWithdrawals == true) {
            limit = "6 Transactions";
        } else {
            limit = "No limit";
        }
        String line = "\n-------------------------------------------------------------------------------\n";
        String tns = "";
        for (Transaction t1 : super.getTransactions()) {
            tns += t1.toString() + "\n";
        }
        String tn = tns.substring(0, tns.length() - 1);
        return toString() + "\nTransaction Limit for withdrawal: " + limit + line + "Transaction Type\tTransaction Time\tAmount\tAdditional Charges\tStatus\n" + tn + line + "Current Balance: " + String.format("%.2f", super.getBalance()) + "\t\tInterest: $" + String.format("%.2f", interestCalculator());
    }

    /**
     * Method which returns NoofWithdrawals
     *
     * @return noOfWithdrawls as int type.
     */
    public int getNoofWithdrawals() {
        int number = 0;
        LocalDateTime today = LocalDateTime.now();
        Month thisMonth = today.getMonth();
        for (Transaction t : super.getTransactions()) {
            if (t.getTrannsactonTime().getMonth() == thisMonth) {
                if (t.getTransactionType() == TransactionType.WITHDRAW) {
                    number++;
                }
            }
        }
        return number;
    }

    @Override
    public String toString() {
        return super.toString() + "\nAccount Type: Savings Account\tInterest Rate: 5.80%";
    }

    /**
     * Based on Transaction Type
     *
     * @param transaction
     * @return
     * @throws exceptions.InsufficentFundsException
     * @throws InsufficentFundsException
     * @throws MaxTransactionsException
     */
    @Override
    public double makeTransaction(Transaction transaction) throws InsufficentFundsException, MaxTransactionsException {
        double bal = 0.0;

        int number = getNoofWithdrawals();
        if (transaction.getTransactionType() == TransactionType.DEPOSIT) {
            transaction.setAdditionalCharges(0.0);
            transaction.setStatus("SUCCESS");
            bal = super.getBalance() + transaction.getAmount();
            transactions.add(transaction);
        } else if (transaction.getTransactionType() == TransactionType.ONLINEPURCHASE) {
            if (transaction.getAmount() < super.getBalance()) {
                transaction.setAdditionalCharges(1.99);
                transaction.setStatus("SUCCESS");
                bal = super.getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
                transactions.add(transaction);
            } else {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("FAILED");
                bal = super.getBalance();
                transactions.add(transaction);
                throw new InsufficentFundsException();
            }
        } else {
            if (transaction.getAmount() <= super.getBalance() && hasLimitedWithdrawals == false) {
                if (number <= 6) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("SUCCESS");
                    bal = super.getBalance() - transaction.getAmount();
                    transactions.add(transaction);
                    number++;
                } else if (number > 6) {
                    if (0.01 * transaction.getAmount() >= 2.59) {
                        transaction.setAdditionalCharges(0.01 * transaction.getAmount());
                    } else {
                        transaction.setAdditionalCharges(2.59);
                    }
                    transaction.setStatus("SUCCESS");
                    bal = super.getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
                    transactions.add(transaction);
                    number++;
                }
            } else if (transaction.getAmount() <= super.getBalance() && hasLimitedWithdrawals == true) {
                if (number <= 6) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("SUCCESS");
                    bal = super.getBalance() - transaction.getAmount();
                    transactions.add(transaction);
                    number++;
                } else if (number >= 6) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("FAILED");
                    bal = super.getBalance();
                    transactions.add(transaction);
                    throw new MaxTransactionsException();
                }
            } else if (transaction.getAmount() > super.getBalance()) {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("FAILED");
                bal = super.getBalance();
                transactions.add(transaction);
                throw new InsufficentFundsException();
            }
        }
        super.setBalance(bal);
        return bal;
    }

    /**
     * Method which returns calculated interest
     *
     * @return
     */
    private double interestCalculator() {
        return super.getBalance() * (SAVING_INTEREST / 100);
    }
}
