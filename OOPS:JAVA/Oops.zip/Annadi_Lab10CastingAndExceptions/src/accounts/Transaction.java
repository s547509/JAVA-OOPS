/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accounts;

import enums.TransactionType;
import java.time.LocalDateTime;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Transaction {

    /**
     * double datatype which stores amount
     */
    public double amount;

    /**
     * Stores LocalDateTime
     */
    public LocalDateTime transactonTime;

    /**
     * Stores the Status of Transaction
     */
    public String status;

    /**
     * stores the additionalCharges
     */
    public double additionalCharges;

    /**
     * Method which Stores type of transaction.
     */
    public TransactionType transactionType;

    /**
     * Transactions Constructor
     *
     * @param transactionType
     * @param amount
     * @param transactonTime
     */
    public Transaction(TransactionType transactionType, double amount, LocalDateTime transactonTime) {
        this.amount = amount;
        this.transactonTime = transactonTime;
        this.transactionType = transactionType;
    }

    /**
     * Setter sets the value of instance variable status with passed parameter.
     *
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Setter method for Additional Charges
     *
     * @param additionalCharges
     */
    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    /**
     * Double DataType Which Stores the Amount
     *
     * @return amount as double type.
     */
    public double getAmount() {
        return amount;
    }

    /**
     * getter method For TransactionTime
     *
     * @return transactonTime as LocalDateTime.
     */
    public LocalDateTime getTrannsactonTime() {
        return transactonTime;
    }

    /**
     * Getter method For Status
     *
     * @return status as String.
     */
    public String getStatus() {
        return status;
    }

    /**
     * Getter method for AdditionalCharges
     *
     * @return additionalCharges as double.
     */
    public double getAdditionalCharges() {
        return additionalCharges;
    }

    /**
     * Getter method that returns TransactionType
     *
     * @return transactionType as transactionType.
     */
    public TransactionType getTransactionType() {
        return transactionType;
    }

    @Override
    public String toString() {
        if (transactionType == TransactionType.DEPOSIT) {
            return transactionType + "\t\t\t\t" + transactonTime + "\t\t$" + String.format("%.2f", amount) + "\t\t" + "\n" + "$" + String.format("%.2f", additionalCharges) + "\t\t" + status;
        } else {
            return transactionType + "\t\t\t" + transactonTime + "\t\t$" + String.format("%.2f", amount) + "\t\t" + "\n" + "$" + String.format("%.2f", additionalCharges) + "\t\t" + status;
        }

    }

}
