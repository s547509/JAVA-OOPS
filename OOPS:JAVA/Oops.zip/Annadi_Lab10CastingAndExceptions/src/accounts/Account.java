/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accounts;

import java.util.ArrayList;
import interfaces.Operations;
import exceptions.OverdraftLimitExceededException;

/**
 *
 * @author Rohith Reddy Annadi
 */
public abstract class Account implements Operations {

    /**
     * Account number of the Account Holder
     */
    public long accountNumber;
    /**
     * Account Balance of the Account Holder
     */

    public double balance;

    /**
     * Customer customer name
     */
    public Customer customer;

    /**
     * ArrayList of all of the transactions
     */
    public ArrayList<Transaction> transactions;

    /**
     * creating an account with the help of constructor
     *
     * @param customer Customer name
     * @param accountNumber account number
     */
    public Account(Customer customer, long accountNumber) {
        this.customer = customer;
        this.accountNumber = accountNumber;
        this.balance = 0.00;
        this.transactions = new ArrayList<Transaction>();
    }

    /**
     * Getter method for account number
     *
     * @return accountNumber
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * getter method to get balance
     *
     * @return balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Getter method to get customer
     *
     * @return customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Getter method to get ArrayList
     *
     * @return transactions
     */
    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    /**
     * Setter method for account number
     *
     * @param accountNumber gives account number
     */
    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Setter method for balance of an account
     *
     * @param balance set the balance
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * Setter method sets customer
     *
     * @param customer set the customer
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    /**
     * setter method sets transaction
     *
     * @param transactions set the transactions
     */
    public void setTransactions(ArrayList<Transaction> transactions) {
        this.transactions = transactions;
    }

    /**
     * generates account statement
     *
     * @return statement
     */
    public String generateStatement() {
        return toString();
    }

    /**
     * Method for transaction
     *
     * @param transaction gives transaction
     * @return transaction
     * @throws Exception gives exception 
     */
    @Override
    public abstract double makeTransaction(Transaction transaction) throws Exception;

    @Override
    public String toString() {
        return customer.toString() + "\nAccount Number: " + accountNumber;
    }

}
