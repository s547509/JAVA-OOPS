/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package accounts;


import enums.TransactionType;
import exceptions.InsufficentFundsException;
import exceptions.MaxTransactionsException;
import exceptions.OverdraftLimitExceededException;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class BankDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException gives exception
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        ArrayList<Account> accnt = new ArrayList<>();
        Scanner sc = new Scanner(new File("input.txt"));
        String so = "";
        SavingsAccount sa = null;
        CurrentAccount ca = null;
        String ar = sc.nextLine();
        while (sc.hasNext()) {
            if (!so.isEmpty()) {
                ar = so;
            }
            String person = sc.nextLine();
            String[] fullName = person.split(" ");
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the customer: " + fullName[0] + "  " + fullName[1]);
            System.out.println("------------------------------------------------------------");
            String dob = sc.nextLine();
            Customer cust = new Customer(fullName[0], fullName[1], dob);
            long accNumber = sc.nextLong();
            sc.nextLine();
            if (ar.equals("savings")) {
                boolean limmit = sc.nextBoolean();
                sa = new SavingsAccount(cust, accNumber, limmit);
                sc.nextLine();
            } else {
                ca = new CurrentAccount(cust, accNumber);
            }
            so = sc.nextLine();
            do {
                String tInfo = so;
                String[] infoSplit = tInfo.split(" ");
                TransactionType v;
                switch (infoSplit[0]) {
                    case "DEPOSIT":
                        v = TransactionType.DEPOSIT;
                        break;
                    case "WITHDRAW":
                        v = TransactionType.WITHDRAW;
                        break;
                    case "ONLINEPURCHASE":
                        v = TransactionType.ONLINEPURCHASE;
                        break;
                    default:
                        v = TransactionType.DEPOSIT;
                        break;
                }
                String[] dateOfTransaction = infoSplit[2].split("-");
                int w = Integer.parseInt(dateOfTransaction[0]);
                int i = Integer.parseInt(dateOfTransaction[1]);
                int u = Integer.parseInt(dateOfTransaction[2]);
                String[] time = infoSplit[3].split(":");
                int n = Integer.parseInt(time[0]);
                int r = Integer.parseInt(time[1]);
                int s = Integer.parseInt(time[2]);
                LocalDateTime date = LocalDateTime.of(w, i, u, n, r, s);
                Transaction transactions = new Transaction(v, Double.parseDouble(infoSplit[1]), date);
                try {
                    if (ar.equals("savings")) {
                        sa.makeTransaction(transactions);
                        System.out.println("The balance after " + v + " in dollars is " + String.format("%.2f", sa.getBalance()));
                    } else {
                        ca.makeTransaction(transactions);
                        System.out.println("The balance after " + v + " in dollars is " + String.format("%.2f", ca.getBalance()));
                    }
                } catch (OverdraftLimitExceededException exe) {
                    System.out.println("exceptions.OverdraftLimitExceededException");

                } catch (MaxTransactionsException exe) {
                    System.out.println("exceptions.MaxTransactionsException");
                } catch (InsufficentFundsException exe) {
                    System.out.println("exceptions.InsufficentFundsException");
                }
                if (sc.hasNext()) {
                    so = sc.nextLine();
                } else {
                    break;
                }
            } while (so.contains("DEPOSIT") || so.contains("WITHDRAW") || so.contains("ONLINEPURCHASE"));
            if (ar.equals("savings")) {
                accnt.add(sa);
            } else {
                accnt.add(ca);
            }
        }
        System.out.println("************************************************************************\n"
                + "*********Invoke getNoofWithdrawals() on SavingsAccount objects**********\n"
                + "************************************************************************");
        for (Account ion : accnt) {
            if (ion.toString().contains("Savings")) {
                SavingsAccount savingsAccount = (SavingsAccount) ion;
                System.out.println(ion.getCustomer().getFirstName() + " made " + savingsAccount.getNoofWithdrawals() + " withdrawals in this month.");
            }
        }
        System.out.println("***********************************************************************\n"
                + "****Invoke generateStatement() on all objects in accounts ArrayList****\n"
                + "************************************************************************");
        for (Account ionn : accnt) {
            System.out.println(ionn.generateStatement());
            System.out.println("*******************************************************************************");
        }
    }

}
