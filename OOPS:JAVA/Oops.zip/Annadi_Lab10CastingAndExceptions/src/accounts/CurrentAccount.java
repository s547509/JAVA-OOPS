/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accounts;

import enums.TransactionType;
import interfaces.Operations;
import exceptions.OverdraftLimitExceededException;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class CurrentAccount extends Account {

    public CurrentAccount(Customer customer, long accountNumber) {
        super(customer, accountNumber);
    }

    /**
     * A transaction according to the type of account
     *
     * @return bal gives balance
     * @throws exceptions.OverdraftLimitExceededException gives exception
     * @throws OverdraftLimitExceededException gives exception
     */
    @Override
    public double makeTransaction(Transaction trans) throws OverdraftLimitExceededException {
        double bal = 0.0;
        double ba = super.getBalance() + Operations.OVERDRAFT_LIMIT;
        if (ba >= trans.getAmount()) {
            if (trans.getTransactionType() == TransactionType.DEPOSIT) {
                trans.setAdditionalCharges(0.0);
                trans.setStatus("SUCCESS");
                bal = super.getBalance() + trans.getAmount();
                transactions.add(trans);
            } else if (trans.getTransactionType() == TransactionType.ONLINEPURCHASE) {
                trans.setAdditionalCharges(1.59);
                trans.setStatus("SUCCESS");
                bal = super.getBalance() - (trans.getAmount() + trans.getAdditionalCharges());
                transactions.add(trans);
            } else {
                trans.setAdditionalCharges(0.0);
                trans.setStatus("SUCCESS");
                bal = super.getBalance() - trans.getAmount();
                transactions.add(trans);
            }
        } else {
            if (trans.getTransactionType() == TransactionType.DEPOSIT) {
                trans.setAdditionalCharges(0.0);
                trans.setStatus("SUCCESS");
                bal = super.getBalance() + trans.getAmount();
                transactions.add(trans);
            } else {
                trans.setAdditionalCharges(0.0);
                trans.setStatus("FAILED");
                bal = super.getBalance();
                transactions.add(trans);
                throw new OverdraftLimitExceededException();
            }
        }
        super.setBalance(bal);
        return bal;
    }

    /**
     * generates the statement of account
     *
     * @return statement
     */
    @Override
    public String generateStatement() {
        String line = "\n-------------------------------------------------------------------------------\n";
        String linetwo = "";
        for (Transaction zone : super.getTransactions()) {
            linetwo += zone.toString() + "\n";
        }
        //String transactionss = transationsss.substring(0, transationsss.length() - 1);
        double blnc;
        if (super.getBalance() < 0) {
            blnc = 0;
        } else {
            blnc = super.getBalance();
        }
        return toString() + line + "Transaction Type\t\tTransaction Time\t\tAmount\t\tAdditional \nCharges\t\tStatus\n" + linetwo.substring(0, linetwo.length() - 1) + line + "Current Balance: " + String.format("%.2f", balance) + "\nOverdraft usage: $" + String.format("%.2f", (Operations.OVERDRAFT_LIMIT - overDraft())) + "\t\tOverdraft available: $" + String.format("%.2f", overDraft());

    }

    @Override
    public String toString() {
        return (this.customer.toString() + "\nAccount Number: " + this.accountNumber
                + "\nAccount Type: Current Account\t" + "Overdraft Limit: $500.00");
    }

    /**
     * Overdraft of account
     *
     * @return overdraft
     */
    private double overDraft() {
        if (super.getBalance() < 0) {
            return super.getBalance() + Operations.OVERDRAFT_LIMIT;
        } else {
            return Operations.OVERDRAFT_LIMIT;
        }
    }
}

