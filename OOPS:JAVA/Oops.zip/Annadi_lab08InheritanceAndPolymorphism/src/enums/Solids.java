/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package enums;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public enum Solids {
    TETRAHEDRON(4), CUBE(6), BOX(6);
    public int noFaces;
    
    /**
     * This is the constructor for Solids class
     * @param noFaces
     */


    private Solids(int noFaces) {
        this.noFaces = noFaces;
    }  
    
    /**
     * This method provides us tetrahedron
     * @return TETRAHEDRON
     */


    public static Solids getTETRAHEDRON() {
        return TETRAHEDRON;
    }
    
    /**
     * This method provides us CUBE
     * @return CUBE
     */


    public static Solids getCUBE() {
        return CUBE;
    }
    
    /**
     * This method provides us BOX
     * @return BOX
     */


    public static Solids getBOX() {
        return BOX;
    }
    
    /**
     * This method provides us NoFaces
     * @return noFaces
     */


    public int getNoFaces() {
        return noFaces;
    }
    
    
    
}