/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package polygon;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class ShapesDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Scanner sc = new Scanner(new File("shapes.txt"));

        ArrayList<Polygon> polygonList = new ArrayList<>();

        while (sc.hasNext()) {

            String angle = sc.next();

            if (angle.equals("cube")) {
                Polygon cube = new Cube(sc.nextDouble());
                polygonList.add(cube);
                sc.nextLine();

            } else if (angle.equals("tetrahedron")) {
                Polygon tetrahyd = new Tetrahedron(sc.nextDouble());
                polygonList.add(tetrahyd);
                sc.nextLine();

            } else if (angle.equals("triangle")) {
                Polygon triangle = new EquilateralTriangle(sc.nextDouble());
                polygonList.add(triangle);
                sc.nextLine();

            } else if (angle.equals("square")) {
                Polygon square = new Square(sc.nextDouble());
                polygonList.add(square);
                sc.nextLine();

            } else {
                angle = Character.toUpperCase(angle.charAt(0)) + angle.substring(1);
                Polygon rp = new RegularPolygon(angle, sc.nextInt(), sc.nextDouble());
                polygonList.add(rp);
                sc.nextLine();
            }
        }

        for (Polygon poly : polygonList) {
            System.out.println("***************");
            System.out.println(poly.toString());
            System.out.println();
        }

        System.out.println("***************");

        double la = 0;
        String nl = "";
        //for largest area
        for (Polygon poly : polygonList) {

            if (poly.getArea() > la) {
                la = poly.getArea();
                nl = poly.getName();
            }
        }

        System.out.println("The polygon with largest area is " + nl + 
                " with area of " + String.format("%.2f", la) + "cm\u00b2");

        for (Polygon poly : polygonList) {

            if (poly.getArea() < la) {
                la = poly.getArea();
                nl = poly.getName();
            }

        }

        System.out.println("The polygon with smallest area is " + nl + 
                " with area of " + String.format("%.2f", la) + "cm\u00b2");

        double largePerimeter = 0;
        String npl = "";
        //for largest area
        for (Polygon poly : polygonList) {
            if (poly.getArea() > largePerimeter) {
                largePerimeter = poly.getPerimeter();
                npl = poly.getName();
            }
        }

        System.out.println("The polygon with largest perimeter is " + npl + 
                " with perimeter of " + String.format("%.2f", largePerimeter) + "cms");

        for (Polygon poly : polygonList) {
            if (poly.getArea() < largePerimeter) {
                largePerimeter = poly.getPerimeter();
                npl = poly.getName();
            }
        }

        System.out.println("The polygon with smallest perimeter is " + npl 
                + " with perimeter of " + String.format("%.2f", largePerimeter) + "cms");

        System.out.println("***************");
        System.out.println("Surface area to Volume ratio of given solids are:");

        String str = "";

        int i = 0;
        String res = "";
        for (Polygon poly : polygonList) {
            if (poly.getName().toUpperCase().equals(enums.Solids.getCUBE().toString())) {
                Cube cube = (Cube) polygonList.get(i);

                str = str + "Cube:" + "\n"
                        + "	Surface area: " + String.format("%.2f", cube.getArea()) + "cm\u00b2" + "\n"
                        + "	Volume: " + String.format("%.2f", cube.getVolume()) + "cm\u00b3" + "\n";
            }
            if (poly.getName().toUpperCase().equals(enums.Solids.getTETRAHEDRON().toString())) {
                Tetrahedron tetra = (Tetrahedron) polygonList.get(i);

                str = str + "Tetrahedron:" + "\n"
                        + "	Surface area: " + String.format("%.2f", tetra.getArea()) + "cm\u00b2" + "\n"
                        + "	Volume: " + String.format("%.2f", tetra.getVolume()) + "cm\u00b3";
            }
            i++;
        }
        System.out.println(str);
        System.out.println("**************");
        System.out.println("I used late binding polymorphism in the line 135");
        System.out.println("**************");
        System.out.println("I used polymorphic substitution in line 38,43,48,53 ");
        System.out.println("**************");


        
    }
    
}