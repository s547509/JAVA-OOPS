/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polygon;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class RegularPolygon extends Polygon {
    private double length;
    
    /**
     * This is the constructor for RegularPolygon class
     * @param name,noSides,length
     */

    public RegularPolygon( String name, int noSides, double length) {
        super(name, noSides);
        this.length = length;
    }
    
    /**
     * This method provides us length
     * @return length
     */
    

    public double getLength() {
        return length;
    }
    
    /**
     * This method provides us Internal Angle
     * @return InternalAngle
     */

    @Override
    public double getInternalAngle() {
        return (180/super.getNoSides())*(super.getNoSides()-2) ; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    /**
     * This method provides us Perimeter
     * @return Perimeter
     */


    @Override
    public double getPerimeter() {
        return super.getNoSides()*length; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    /**
     * This method provides us Area
     * @return Perimeter
     */

    @Override
    public double getArea() {
        return (0.25*super.getNoSides()*length*length)*(1/(Math.tan(3.14/super.getNoSides()))); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    /**
     * This method provides us InCircle Radius
     * @return InCircleRadius
     */
    
    public double getInCircleRadius(){
        return (length/2.0)*(1/Math.tan(3.14/super.getNoSides()));
    }
    
    /**
     * This method provides us CircumCircle Radius
     * @return CircumCircleRadius
     */
    
    public double getCircumCircleRadius(){
        return (length/2.0)*(1/Math.sin(3.14/super.getNoSides()));
    }
    
    /**
     * This method returns String type with all values
     */

    @Override
    public String toString() {
        return "Polygon: " + getName() + "\n"
                + "Number of Sides: " + super.getNoSides() + "\n"
                + "Length of Side: " + String.format("%.1f", length) + "cms" + "\n"
                + "Internal Angle: " + String.format("%.2f", getInternalAngle()) + "\u00b0" + "\n"
                + "CircumCircle Radius: " + String.format("%.2f", getCircumCircleRadius()) + "cms" + "\n"
                + "InCircle Radius: " + String.format("%.2f", getInCircleRadius()) + "cms" + "\n"
                + "Area: " + String.format("%.2f", getArea()) + "cm\u00b2" + "\n"
                + "Perimeter: " + String.format("%.2f", getPerimeter()) + "cms";
    }
    
    

    
    
    
    
}