/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polygon;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Polygon {
    private String name;
    private int noSides;
    
    /**
     * This is the constructor for polygon class
     * @param name,noSides
     */

    public Polygon(String name, int noSides) {
        this.name = name;
        this.noSides = noSides;
    }
    
    /**
     * This method provides us name
     * @return name
     */

    public String getName() {
        return name;
    }
    
        /**
     * This method provides us num of Sides
     * @return noSides
     */


    public int getNoSides() {
        return noSides;
    }
    
    /**
     * This method provides us Area
     * @return Area
     */
    
    public double getArea(){
        return 0.0;
    }
    
    /**
     * This method provides us perimeter
     * @return perimeter
     */
    
    public double getPerimeter(){
        return 0.0;
    }
    
    /**
     * This method provides us InternalAngle
     * @return internalAngle
     */
    
    public double getInternalAngle(){
        return 0.0;
    }
    
    /**
     * This method returns String type with all values
     */


    @Override
    public String toString() {
        return "Polygon{" + "name=" + name + ", noSides=" + noSides + '}';
    }
    
    
    
}