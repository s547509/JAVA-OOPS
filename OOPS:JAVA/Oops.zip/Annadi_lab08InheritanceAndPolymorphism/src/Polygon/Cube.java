/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polygon;

import enums.Solids;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Cube extends Square {
    
    /**
     * This is the constructor for the cube class
     * @param length 
     */

    public Cube(double length) {
        super("Cube",length);
        
    }
    
    /**
     * This method provides the area of the cube
     * @return Area
     */


    @Override
    public double getArea() {
        return super.getArea()*Solids.getCUBE().getNoFaces(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    /**
     * This method provides the volume
     * @return Volume
     */

    
    public double getVolume(){
        return super.getLength()*super.getLength()*super.getLength();
    }
    
    /**
     * This method provides us the InSpRadius
     * @return InSphereRadius
     */

    
    public double getInSphereRadius(){
        return super.getLength()*0.5;
    }
    
    /**
     * This method provides us the CircumSphRadius
     * @return CircumSphereRadius
     */
    
    public double getCircumSphereRadius(){
        return Math.sqrt(3)*0.5*super.getLength();
    }
    
    /**
     * This method returns  String type with all  values
     */


    @Override
    public String toString() {
        return "Polygon: " + getName()+"\n"+
                      "Number of Sides: "+super.getNoSides()+"\n"+
                      "Length of Side: "+String.format("%.1f", super.getLength())+"cms"+"\n"+
                      "Internal Angle: "+String.format("%.2f", getInternalAngle())+"\u00b0"+"\n"+
                      "CircumCircle Radius: "+String.format("%.2f", getCircumCircleRadius())+"cms"+"\n"+
                      "InCircle Radius: "+String.format("%.2f", getInCircleRadius())+"cms"+"\n"+
                      "Area: "+String.format("%.2f", getArea())+"cm\u00b2"+"\n"+
                      "Perimeter: "+String.format("%.2f", getPerimeter())+"cms"+"\n"+
                      "InSphere Radius: "+String.format("%.2f", getInSphereRadius())+"cms"+"\n"+
                      "CircumSphere Radius: "+String.format("%.2f", getCircumSphereRadius())+"cms"+"\n"+
                      "Volume: "+String.format("%.2f", getVolume())+"cm\u00b3";
    }

    
    
    
}
       