/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polygon;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Square extends RegularPolygon {
    
    /**
     * This is the constructor for Square class
     * @param length
     */

    public Square(double length) {
        super("Square",4,length);
        
    }
    
    
    /**
     * This is the constructor for Square class
     * @param name,length
     */
    
    public Square(String name,double length){
        super( name,4,length);
       
    }
    
    
}