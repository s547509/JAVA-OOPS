/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polygon;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Rohith Reddy Annadi
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class EquilateralTriangle extends RegularPolygon {
    
    /**
     * This is  constructor for EquilateralTriangle class
     * @param length 
     */


    public EquilateralTriangle(double length) {
        super( "Equilateral Triangle", 3,length);
        
    }
    
    /**
     * This is constructor for EquilateralTriangle class
     * @param length,name
     */


    public EquilateralTriangle( String name,double length) {
        super(name,3,length);
        
    }
    
    /**
     * This method provides height
     * @return Height
     */

    
    public double getHeight(){
        return (Math.sqrt(3)/2.0)*super.getLength();
    }
    
    /**
     * This method returns  String type with all  values
     */
    
    @Override
    public String toString() {
        return "Polygon: " + getName() + "\n"
                + "Number of Sides: " + super.getNoSides() + "\n"
                + "Length of Side: " + String.format("%.1f", super.getLength()) + "cms" + "\n"
                + "Internal Angle: " + String.format("%.2f", super.getInternalAngle()) + "\u00b0" + "\n"
                + "CircumCircle Radius: " + String.format("%.2f", super.getCircumCircleRadius()) + "cms" + "\n"
                + "InCircle Radius: " + String.format("%.2f", super.getInCircleRadius()) + "cms" + "\n"
                + "Area: " + String.format("%.2f", super.getArea()) + "cm\u00b2" + "\n"
                + "Perimeter: " + String.format("%.2f", super.getPerimeter()) + "cms" + "\n"
                + "Height: " + String.format("%.2f", getHeight()) + "cms";
    }
    
    
    
}