/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employees;

/**
 *
 * @author s547509
 */
public class FullTimeEmployee extends Employee{

    private boolean benefits;

    public void setBenefits(boolean benefits) {
        this.benefits = benefits;
    }

    public boolean isBenefits() {
        return benefits;
    }

    public FullTimeEmployee(boolean benefits, String fName, String lName, String ssn) {
        super(fName, lName, ssn);
        this.benefits = benefits;
    }
    
    
    @Override
    public double clacSalary() {
    return 3000;   
    }

   
    
    
}
