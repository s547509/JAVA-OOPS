/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employees;

/**
 *
 * @author s547509
 */
public abstract class HourlyEmployee extends Employee {
    private int hrsWorked;
    private double wageRate;

    public void setHrsWorked(int hrsWorked) {
        this.hrsWorked = hrsWorked;
    }

    public void setWageRate(double wageRate) {
        this.wageRate = wageRate;
    }

    public int getHrsWorked() {
        return hrsWorked;
    }

    public double getWageRate() {
        return wageRate;
    }

    public HourlyEmployee(int hrsWorked, double wageRate, String fName, String lName, String ssn) {
        super(fName, lName, ssn);
        this.hrsWorked = hrsWorked;
        this.wageRate = wageRate;
    }

    @Override
    public String toString() {
        return "HourlyEmployee{" + "hrsWorked=" + hrsWorked + ", wageRate=" + wageRate + '}';
    }
    
    
}
