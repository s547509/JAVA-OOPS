/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employees;

/**
 *
 * @author s547509
 */
public class FrontDeskEmployee extends HourlyEmployee{
    private int overTimehours;

    public FrontDeskEmployee(int overTimehours, int hrsWorked, double wageRate, String fName, String lName, String ssn) {
        super(hrsWorked, wageRate, fName, lName, ssn);
        this.overTimehours = overTimehours;
    }

    public int getOverTimehours() {
        return overTimehours;
    }

    public void setOverTimehours(int overTimehours) {
        this.overTimehours = overTimehours;
    }

    @Override
    public String toString() {
        return "FrontDeskEmployee{" + "overTimehours=" + overTimehours + '}';
    }

   

    @Override
    public double clacSalary() {
         if(overTimehours >=1){
            return super.getHrsWorked()*super.getWageRate()+100;
            
        }
        else {
            return super.getHrsWorked()*super.getWageRate();
        }
//        /throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
    
  
    
    
}
