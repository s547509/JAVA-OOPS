/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employees;

/**
 *
 * @author s547509
 */
public class EmployeeDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       // Employee emp= new Employee("A","B","123");
              //cannot create an object for abstract classses without implementing abstrract methods
    
    //HourlyEmployee hrEmp = new HourlyEmployee(0,0,"fName","lName");
   // FullTimeEmployee ftEmp = new FullTimeEmployee(true,"A","B","1234");
    //System.out.println(ftEmp.calcSqalary());
    FrontDeskEmployee fdEmp = new FrontDeskEmployee(10,12,15,"y","N","6767");
        System.out.println(fdEmp.clacSalary());
       Employee fDEmp1 = new FrontDeskEmployee(2,12,23,"Y","O","1234");
       System.out.println(fDEmp1.clacSalary());
       System.out.println(fDEmp1.getSsn());
    
    }
    
    
}
