
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package flights;

/**
 *
 * @author S547509
 */
public class FlightDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Flight f1 = new Flight("Jet",3,10.0);
        Flight f2 = new Flight("AirIndia",2,12.0);
        Flight f3 = new Flight("Delta",4,15.0);
        System.out.println(f1.getFlightName());
        
        
        
       String fName = f1.getFlightName();
        System.out.println(fName);
        
        
        f1.setFlightName("unitedAirlines");
        System.out.println(f1.getFlightName());
        
        
        f2.getFlightName();
        System.out.println(f2.getFlightName());
        f2.setFlightName("Emirates");
        
        System.out.println(f2.getFlightName());
        
        String gName = f3.getFlightName();
        System.out.println(gName);
     
        int f3Duration = f3.getFlightDuration();
        System.out.println(f3Duration);
        
        f3.setFlightDuration(67);
        
        System.out.println(f3Duration);
        
        
        
        
        
        double tName = f3.getFlightPrice();
        System.out.println(tName);
        
        
        System.out.println(f1.getFlightDuration());
        
   String fName1 = f1.getFlightName();
        System.out.println(fName1);
        
        f1.setFlightName("luftansa");
        System.out.println(f1.getFlightName());
        
      double dName = f3.getFlightPrice();
        System.out.println(dName);
        
        f3.setFligtprice(2000);
        System.out.println(f3.getFlightPrice());
    }
    
}
