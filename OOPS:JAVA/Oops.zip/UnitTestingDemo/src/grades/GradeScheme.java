/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grades;

/**
 *
 * @author S547509
 */
public class GradeScheme {

    public static String getGrade(int score) {
        if (score <= 50) {
            return "Error";
        } else if (score > 50 && score < 60) {
            return "F";
        } else if (score > 60 && score < 70) {
            return "D";
        } else if (score > 70 && score < 80) {
            return "C";
        } else if (score > 80 && score < 90) {
            return "B";
        } else {
            return "A";
        }

    }

}
