/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package students;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author S547509
 */
public class StudentDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        ArrayList<Student> stuList = new ArrayList<>();
        Scanner scan = new Scanner(new File("studentData.txt"));
        
        while(scan.hasNext()){
            Student s = new Student(scan.nextInt(),scan.next(),scan.next(),scan.nextDouble());
            stuList.add(s);
        }
        System.out.println("******printing students after reading the data******");
        for(Student s : stuList){
            System.out.println(s);
            
        }
        
        System.out.println("*******printing students in natural order sorting based on gpa*******");
        Collections.sort(stuList);
        for(Student s : stuList){
            System.out.println(s);
            
        }
        
        System.out.println("****Overriding students after natural  order sorting based on idNum*****");
        Collections.sort(stuList, new Comparator<Student>() {

            @Override
            public int compare(Student s1, Student s2) {
                if (s1.getFirstName().compareTo(s2.getFirstName()) == 0) {
                    return s1.getFirstName().compareTo(s2.getFirstName());
                } else {
                    return s1.getLastName().compareTo(s2.getLastName());
                }

            }
        }
        );
        PrintList(stuList);
        
        System.out.println("****Overriding students using seperate class*****");
        Collections.sort(stuList, new StudentComparator());
        PrintList(stuList);
        Integer x = 10;
        Integer y = 20;
        
        System.out.println(x.compareTo(y));
        System.out.println(x.compareTo(x));
        System.out.println(y.compareTo(x));
        
        
    }
    
    private static void PrintList(ArrayList<Student> sList){
        for(Student s : sList){
            System.out.println(s);
            
        }
        
    }
}
