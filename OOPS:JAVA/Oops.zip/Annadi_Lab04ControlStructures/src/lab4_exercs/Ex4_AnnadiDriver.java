/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab4_exercs;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Ex4_AnnadiDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double fees = 0.10;
        Ex4_Annadi a1 = new Ex4_Annadi();
        System.out.println("Dice 1: " + a1.throwDice1());
        System.out.println("Dice 2: " + a1.throwDice2());
        System.out.println("The sum of Dice 1 and Dice 2 is:  " + a1.sumDice1Dice2());
        if(a1.sumDice1Dice2() >= 10){
            System.out.println("Free passage");
        }
        else{
            fees = fees * 2 * a1.sumDice1Dice2();
            System.out.println("Pay a fee: " + fees);
        }
    }
    
}
