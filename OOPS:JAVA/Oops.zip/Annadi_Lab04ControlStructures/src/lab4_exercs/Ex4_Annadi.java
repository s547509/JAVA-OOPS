/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab4_exercs;

import java.util.Random;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Ex4_Annadi {
    
    /* This class provides methods by throwing dice and checks if the fee applies 
    or if it is a free passage */
    
    Random random = new Random();
    int random1 = 5 + random.nextInt(6);
    int random2 = 1 + random.nextInt(6);
    
    

    public Ex4_Annadi() {
    }
    
    /**
     * 
     * @return random values
     */

    public Random getRandom() {
        return random;
    }
    
    /**
     * 
     * @return random1 values
     */

    public int getRandom1() {
        return random1;
    }
    
    /**
     * 
     * @return random2 values
     */

    public int getRandom2() {
        return random2;
    }
    
    /**
     * 
     * @param random is to set the random value
     */
    
    public void setRandom(Random random) {
        this.random = random;
    }
    
    /**
     * 
     * @param random1 is to set the random1 value
     */

    public void setRandom1(int random1) {
        this.random1 = random1;
    }

    public void setRandom2(int random2) {
        this.random2 = random2;
    }
    
    /**
     * 
     * @return throwDice1 gives random value for 1st dice throw
     */
    
    public int throwDice1( ){
        return random1;
    }
    
    /**
     * 
     * @return throwDice2 gives random value for 2nd dice throw
     */
    
    public int throwDice2(){
        return random2;
    }
    
    /**
     * 
     * @return sumDice1Dice2 gives sum of range values in 2 throws
     */
    
    public int sumDice1Dice2( ){
        return throwDice1( ) + throwDice2();
    }
    
    /**
     * 
     * @return fee details
     */

    @Override
    public String toString() {
        return "Ex4_Annadi{" + "random=" + random + ", random1=" + random1 + ","
                + " random2=" + random2 + '}';
    }
    
    
    
    
}
