/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab4_exercs;

import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Ex1_AnnadiDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        Ex1_Annadi objp = new Ex1_Annadi();
        System.out.println(" ***** Welcome to Zombie's  & Gombie ***** ");
        System.out.println("What is your  name?  ");
        String customerName = scan.nextLine();
        System.out.println("Pizza Size (inches)  Cost");
        System.out.println("        10            $10.99");
        System.out.println("        12            $12.99");
        System.out.println("        14            $14.99");
        System.out.println("        16            $16.99");
        double cost = 10.99;
        int pizzaSize = 0;
        if (pizzaSize == 10)
        {
            objp.setPizzaSize(10);
            objp.setCost(10.99);
        }
        else if (pizzaSize == 12)
        {
            objp.setPizzaSize(12);
            objp.setCost(12.99);
        }
        else if (pizzaSize == 14)
        {
            objp.setPizzaSize(14);
            objp.setCost(14.99);
        }
        else if (pizzaSize == 16)
        {
            objp.setPizzaSize(16);
            objp.setCost(16.99);
        }
        System.out.println("What size of pizza would you like?");
        System.out.println("10'', 12'', 14'', or 16'' (Enter one size only): ");
        pizzaSize = scan.nextInt();
        System.out.println("Are you a student? (Y/N):");
        char isStudent = scan.next().charAt(0);
        if(isStudent == 'Y' || isStudent == 'y'){
            objp.setDiscount(2);
        }
        System.out.println("You are eligible for a $" + objp.getDiscount() + "discount");
        System.out.println(" What type of crust would you like to have?");
        System.out.println("(T) Thin Crust, (O) Original Crust , or (S) Skillet Crust(enter T, O, or S): ");
        scan.nextLine();
        char isCrust = scan.next().charAt(0);
        switch (isCrust){
            case 'T':
            case 't':
                objp.setCrust("Thin Crust");
                break;
            case 'O':
            case 'o':
                objp.setCrust("Original Crust");
                break;
            case 'S':
            case 's':
                objp.setCrust("Skillet Crust");
                break;       
        }
        System.out.println("All pizzas come with cheese.");
        System.out.println("Additional toppings are $0.75 each, choose from:");
        System.out.println("Beef, Tomatoes, Black Olives,  Mushrooms, Green Peppers ");
        System.out.println("Would you like to add beef? (Y/N): ");
        char option = scan.next().charAt(0);
        int toppingsCount = 0;
        String toppings = "Cheese";
        if (option == 'Y' || option == 'y'){
            toppingsCount = toppingsCount + 1;
            toppings = toppings + "beef";
        }
        System.out.println("Would you like to add Tomatoes? (Y/N): ");
        option = scan.next().charAt(0);
        if (option == 'Y' || option == 'y'){
            toppingsCount = toppingsCount + 1;
            toppings = toppings + "Tomatoes";
        }
        System.out.println("Would you like to add Black Olives? (Y/N): ");
        option = scan.next().charAt(0);
        if (option == 'Y' || option == 'y'){
            toppingsCount = toppingsCount + 1;
            toppings = toppings + "Black Olives";
        }
        System.out.println("Would you like to add Mushrooms? (Y/N): ");
        option = scan.next().charAt(0);
        if (option == 'Y' || option == 'y'){
            toppingsCount = toppingsCount + 1;
            toppings = toppings + "Green Peppers";
        }
        System.out.println("Would you like to add Green Peppers? (Y/N): ");
        option = scan.next().charAt(0);
        if (option == 'Y' || option == 'y'){
            toppingsCount = toppingsCount + 1;
            toppings = toppings + "Green Peppers";
        }
        
        System.out.println("-> Your order is as follows: ");
        System.out.println(pizzaSize + "inch pizza");
        System.out.println("-> " + objp.getCrust());
        objp.setToppings(toppings);
        System.out.println("-> " + objp.getToppings());
        objp.setCost(cost + (0.75 * toppingsCount));
        objp.setCost(cost + (0.75 * toppingsCount));
        cost = objp.getCost() - objp.getDiscount();
        System.out.println("The cost of your order is: $" + cost);
        double totalTax = (double) Math.round((objp.getTaxRate()*cost)*100)/100;
        System.out.println("The tax is: $" + totalTax);
        double totalDue = (double) Math.round((cost + objp.getTaxRate()*cost) * 100)/100;
        System.out.println("The total due is:  $" + totalDue );
        System.out.println("-> Enjoy your Pizza and your order will be ready  in 20 minutes.");
        
        
        
        
        
    }
    
}
