/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab4_exercs;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Ex2_AnnadiDriver {

    /**
     * @return a which is divisible by 7
     */
    
    public int IsDivisibleby7(int a){
        int p = 0;
        p = a % 10;
        int q = p * 2;
        int d = (a / 10) - q;
        if(d % 7 == 0){
            return a;
        }
        return 0;
    }
    
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Scanner scan = new Scanner(new File("lab4datafile.txt"));
        Ex2_AnnadiDriver e1 = new Ex2_AnnadiDriver();
        PrintWriter w1 = new PrintWriter(new File("even.txt"));
        PrintWriter w2 = new PrintWriter(new File("odd.txt"));
        PrintWriter w3 = new PrintWriter(new File("seven.txt"));
        int number;
        int eCount = 0;
        int oCount = 0;
        int dsCount = 0;
        while(scan.hasNext()){
            number = scan.nextInt();
            if(number % 2 == 0){
                int e = number;
                w1.println(e);
                eCount = eCount + 1;
            }
            else{
                int o = number;
                w2.println(0);
                oCount = oCount + 1;
            }
            int ds = e1.IsDivisibleby7(number);
            if(number == ds){
                w3.println(ds);
                dsCount = dsCount + 1;                
            }
        }
        System.out.println("Number  of  odd  numbers:  " + oCount);
        System.out.println("Number  of  even  numbers : " + eCount);
        System.out.println("Number of numbers divisible by 7: " + dsCount );
    }
    
}
