/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab4_exercs;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Ex1_Annadi {
    
    /* This class provides methods to calculate the cost of pizza */
    
    private String customerName;
    private int pizzaSize;
    private char isStudent;
    private double discount;
    private String crust;
    private String toppings;
    private double taxRate = 0.08;
    private double cost = 0.0;
    private double totalDue;
    
    //Parameterized constructor
    /**
     * 
     * @param customerName gives the name of the customer
     * @param pizzaSize gives the size of the pizza
     * @param isStudent validates if the customer is student or not
     * @param discount provides the discount
     * @param crust provides the crust details
     * @param toppings provides the toppings details
     * @param taxRate provides the tax rate
     * @param totalDue provides the total due
     */

    

    public Ex1_Annadi(String customerName, int pizzaSize, char isStudent, 
            double discount, String crust, String toppings, double taxRate, double totalDue) {
        this.customerName = customerName;
        this.pizzaSize = pizzaSize;
        this.isStudent = isStudent;
        this.discount = discount;
        this.crust = crust;
        this.toppings = toppings;
        this.taxRate = taxRate;
        this.totalDue = totalDue;
    }

    public Ex1_Annadi() {
    }
    
    /**
     * 
     * @return customerName of the person who orders the pizza
     */
    

    public String getCustomerName() {
        return customerName;
    }
    
    /**
     * 
     * @return pizzaSize of the pizza
     */

    public int getPizzaSize() {
        return pizzaSize;
    }
    
    /**
     * 
     * @return isStudent which checks if the customer is student or not 
     */

    public char getIsStudent() {
        return isStudent;
    }
    
    /**
     * 
     * @return discount of the order
     */

    public double getDiscount() {
        return discount;
    }
    
    /**
     * 
     * @return crust details of pizza
     */

    public String getCrust() {
        return crust;
    }
    
    /**
     * 
     * @return toppings details of pizza
     */

    public String getToppings() {
        return toppings;
    }
    
    /**
     * 
     * @return taxRate details of order
     */


    public double getTaxRate() {
        return taxRate;
    }
    
    /**
     * 
     * @return cost of order
     */

    public double getCost() {
        return cost;
    }
    
    /**
     * 
     * @return totalDue of order
     */

    public double getTotalDue() {
        return totalDue;
    }
    
    /**
     * 
     * @param customerName sets the name of customer
     */

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    /**
     * 
     * @param pizzaSize sets the size of pizza
     */

    public void setPizzaSize(int pizzaSize) {
        this.pizzaSize = pizzaSize;
    }
    
     /**
     * 
     * @param isStudent sets the  if the customer is student
     */

    public void setIsStudent(char isStudent) {
        this.isStudent = isStudent;
    }
    
     /**
     * 
     * @param discount sets the discount details and amount
     */

    public void setDiscount(double discount) {
        this.discount = discount;
    }
    
    /**
     * 
     * @param crust sets type of crust
     */

    public void setCrust(String crust) {
        this.crust = crust;
    }
    
    /**
     * 
     * @param toppings sets type of pizza toppings
     */

    public void setToppings(String toppings) {
        this.toppings = toppings;
    }
    
    /**
     * 
     * @param taxRate sets  the amount of tax  
     */

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }
    
    /**
     * 
     * @param cost sets  the cost of pizza  
     */

    public void setCost(double cost) {
        this.cost = cost;
    }
    
    /**
     * 
     * @param totalDue sets  the totalAmount of pizza  
     */

    public void setTotalDue(double totalDue) {
        this.totalDue = totalDue;
    }
    
    /**
     * 
     * @return pizza bill details
     */

    @Override
    public String toString() {
        return "Ex1_Annadi{" + "customerName=" + customerName + ", pizzaSize=" + pizzaSize + ", isStudent=" + isStudent + ", discount=" + discount + ", crust=" + crust + ", toppings=" + toppings + ", taxRate=" + taxRate + ", cost=" + cost + ", totalDue=" + totalDue + '}';
    }
    
    
}
