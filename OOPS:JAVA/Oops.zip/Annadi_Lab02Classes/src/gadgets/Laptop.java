/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gadgets;

/**
 *
 * @author Rohith Reddy Annadi
 */

public class Laptop
{
 private String brand;
 private String processor;
 private double screenSize;
 private int memorySize;
 private String osName;
 private boolean touch;
 
 /**
     * Parameterized constructor for the Laptop Class.
     * @param brand is the Laptop Brand name like HP/Asus
     * @param processor is the name of the processor
     * @param screenSize is the screen size in inches
     * @param memorySize is the Memory size in GB’s 
     * @param osName is the Operating System name like Windows/Linux
     * @param touch is the supported format touch screen or not.
     */

    public Laptop(String brand, String processor, String osName, int memorySize, 
            double screenSize, boolean touch) 
    {
        this.brand = brand;
        this.processor = processor;
        this.osName = osName;
        this.screenSize = screenSize;
        this.memorySize = memorySize;
        this.touch = touch;
        
    }

    public Laptop()
    {
    }
    
    /**
     * Getter method is used for the Brand
     * @return's brand
     */

    public String getBrand() {
        return brand;
    }
    
     /**
     * Getter method is used for the Processor
     * @return's processor
     */

    public String getProcessor() {
        return processor;
    }
    
     /**
     * Getter method is used for the ScreenSize
     * @return screenSize
     */

    public double getScreenSize() {
        return screenSize;
    }
    
     /**
     * Getter method is used for the MemorySize
     * @return's memorySize
     */

    public int getMemorySize() {
        return memorySize;
    }
    
     /**
     * Getter method is used for the OsName
     * @return's osName
     */

    public String getOsName() {
        return osName;
    }
    
     /**
     * Getter method is used to set if the screen is touch or not
     * @return boolean value, if touch format or not
     */

    public boolean isTouch() {
        return touch;
    }
    
     /**
     * set method is used to the set Brand
     * @param brand
     */

    public void setBrand(String brand) {
        this.brand = brand;
    }
    
     /**
     * set method is used to set the Processor
     * @param processor
     */

    public void setProcessor(String processor) {
        this.processor = processor;
    }
    
     /**
     * set method is used to set the ScreenSize
     * @param screenSize
     */

    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }
    
     /**
     * set method is used to set the MemorySize
     * @param memorySize
     */

    public void setMemorySize(int memorySize) {
        this.memorySize = memorySize;
    }
    
     /**
     * set method is used to the set OsName
     * @param osName
     */

    public void setOsName(String osName) {
        this.osName = osName;
    }
    
     /**
     * set method is used to set the Touch format
     * @param touch
     */

    public void setTouch(boolean touch) {
        this.touch = touch;
    }
    
 public String toString()
 {
     return "Laptop Brand: " + brand + "\n" + 
             "Laptop Processor: " + processor + "\n" +
             "Laptop Operating System: " + osName + "\n" + 
             "Laptop Hard Drive: " + memorySize + "\n" + 
             "Laptop Display: " + screenSize + "\n" + 
             "Laptop Is Touch: " + touch ;
 }
}

