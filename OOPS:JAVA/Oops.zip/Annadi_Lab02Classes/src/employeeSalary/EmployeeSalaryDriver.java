/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeeSalary;

import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class EmployeeSalaryDriver {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Testing the EmployeeSalary class: ");
        System.out.println("Enter the wage per hour of the Employee: $");
        double wagePerHour = scan.nextDouble();
        System.out.println("Enter the insurance percentage of the Employee in percentage: ");
        double insurancePercentage = scan.nextDouble();
        System.out.println("Enter the tax percentage of the Employee in percentage: ");
        double taxPercentage = scan.nextDouble();
        System.out.println("Enter the pf percentage of the Employee in percentage: ");
        double pfPercentage = scan.nextDouble();
        System.out.println("Enter the bonus of the Employee: ");
        double bonus = scan.nextDouble();
        
        EmployeeSalary obj1EmpSal = new EmployeeSalary(30.0, 9.5, 12.35, 10.0);
        System.out.println("The details of obj1EmpSal object are as follows: \n" + 
                obj1EmpSal.toString());
        
        System.out.println("The monthly salary of the Employee is: $" + obj1EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + obj1EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + obj1EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $" + obj1EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + obj1EmpSal.calcAnnualNetPay(bonus));
        System.out.println("**************************************************");
        
        EmployeeSalary Obj2EmpSal = new EmployeeSalary();
        System.out.println("The details of obj2EmpSal object are as follows: \n" + Obj2EmpSal.toString());
        System.out.println("The monthly salary of the Employee is: $" + Obj2EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + Obj2EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + Obj2EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $"+ Obj2EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + Obj2EmpSal.calcAnnualNetPay(bonus));
        Obj2EmpSal.setWagePerHour(35.0);
        Obj2EmpSal.setInsurancePercentage(12.50);
        Obj2EmpSal.setTaxPercentage(11.45);
        Obj2EmpSal.setPfPercentage(10.5);
        System.out.println("Enter the new bonus of the Employee: ");
        bonus = scan.nextDouble();
        
        System.out.println("The details of Obj2EmpSal object are as follows: \n" + Obj2EmpSal.toString());
        System.out.println("The monthly salary of the Employee is: $" + Obj2EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is: $" + Obj2EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is: $" + Obj2EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $" + Obj2EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $" + Obj2EmpSal.calcAnnualNetPay(bonus));
        
    }
    
}
 