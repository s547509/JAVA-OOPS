/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeeSalary;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class EmployeeSalary {
    private double wagePerHour;
    private double insurancePercentage;
    private double taxPercentage;
    private double pfPercentage;
    private int HOURS = 40;
    
    /**
     * Parameterized constructor for EmployeeSalary Class.
     * @param wagePerHour is the employee's hourly pay rate
     * @param insurancePercentage is the Insurance rate
     * @param taxPercentage is the Tax percentage
     * @param pfPercentage is the PF percentage
     */

    public EmployeeSalary(double wagePerHour, double insurancePercentage, 
            double taxPercentage, double pfPercentage) {
        this.wagePerHour = wagePerHour;
        this.insurancePercentage = insurancePercentage;
        this.taxPercentage = taxPercentage;
        this.pfPercentage = pfPercentage;
        
    }

    public EmployeeSalary() {
    }
    
    /**
     * Getter method is for the WagePerHour
     * @return's the wagePerHour
     */


    public double getWagePerHour() {
        return wagePerHour;
    }
    
     /**
     * Getter method is used for the InsurancePercentage
     * @return's the insurancePercentage
     */

    public double getInsurancePercentage() {
        return insurancePercentage;
    }
    
    /**
     * Getter method is used for the TaxPercentage
     * @return's the taxPercentage
     */

    public double getTaxPercentage() {
        return taxPercentage;
    }
    
    /**
     * Getter method is used for the PfPercentage
     * @return's the pfPercentage
     */


    public double getPfPercentage() {
        return pfPercentage;
    }
    
     /**
     * Getter method is used for the HOURS
     * @return's the HOURS
     */

    public int getHOURS() {
        return HOURS;
    }
    
    /**
     * set method is used to set the WagePerHour
     * @param wagePerHour
     */

    public void setWagePerHour(double wagePerHour) {
        this.wagePerHour = wagePerHour;
    }
    
    /**
     * set method is used to set the InsurancePercentage
     * @param insurancePercentage
     */

    public void setInsurancePercentage(double insurancePercentage) {
        this.insurancePercentage = insurancePercentage;
    }
    
    /**
     * set method is used to set the TaxPercentage
     * @param taxPercentage
     */

    public void setTaxPercentage(double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }
    
    /**
     * set method is used to set the PfPercentage
     * @param pfPercentage
     */

    public void setPfPercentage(double pfPercentage) {
        this.pfPercentage = pfPercentage;
    }
    
     /**
     * set method is used to set the HOURS
     * @param HOURS
     */


    public void setHOURS(int HOURS) {
        this.HOURS = HOURS;
    }
    
     /**
     * Method is used to calculate monthly salary
     * @return's double, monthly salary
     */
    
    public double calcMonthlySalary()
    {
        return 4*HOURS*wagePerHour;
    }
    
     /*
     * Method is used to calculate monthly insurance
     * @return's double, monthly insurance
     */
    
    public double calcMonthlyInsurance()
    {
        return calcMonthlySalary()*(insurancePercentage)/100;
    }
    
     /*
     * Method is used to calculate monthly Pf Amount
     *  @return's double, monthly Pf Amount
     */
    
    public double calcMonthlyPfAmount()
    {
        return calcMonthlySalary()*(pfPercentage)/100;
    }
    
     /*
     * Method is used to calculate Annual Gross Salary
     * @return's double, Annual Gross Salary
     */
    
    public double calcAnnualGrossSalary(double bonus)
    {
        return bonus+ 12*calcMonthlySalary();
    }
    
     /*
     * Method is used to calculate Annual Net Pay
     * @return's double, Annual Net Pay
     */
    
    public double calcAnnualNetPay(double bonus)
    {
        return calcAnnualGrossSalary( bonus) - 
        (calcAnnualGrossSalary(bonus)*taxPercentage/100) - 
        12*calcMonthlyInsurance() - 12*calcMonthlyPfAmount();
    }
    
     /**
     * This method returns the output string containing all the parameters.
     * @return's String
     */

    @Override
    public String toString() {
        return "wagePerHour: " + wagePerHour + ", insurancePercentage: " + 
                insurancePercentage + ", taxPercentage: " + taxPercentage + 
                ", pfPercentage: " + pfPercentage + ", HOURS: " + HOURS;
    }
    
}
 