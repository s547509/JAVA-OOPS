/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Dogs;

/**
 *
 * @author S547509
 */
public class dogDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Dog[] myDogs = new Dog[5];
        Dog d1 = new Dog("doggy", 2, 10);
        Dog d2 = new Dog("pappy", 3, 20);
        Dog d3 = new Dog("slippy", 4, 30);
        Dog d4 = new Dog("flappy", 5, 40);
        Dog d5 = new Dog("dappy", 6, 50);
        
        myDogs[0] = d1;
        myDogs[1] = d2;
        myDogs[2] = d3;
        myDogs[3] = d4;
        myDogs[4] = d5;
        
        
        for(Dog d:myDogs){
            System.out.println(d.getName().substring(1));
        }
        
       
        int sum = 0;
        for(Dog d:myDogs){
            double age = d.getAge();
            sum += age;
            double average = sum / myDogs.length;
            System.out.println(average);
        }
            
    
    } 
}
