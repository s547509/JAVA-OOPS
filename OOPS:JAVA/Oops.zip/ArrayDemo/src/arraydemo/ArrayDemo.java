/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arraydemo;

/**
 *
 * @author S547509
 */
public class ArrayDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // create an array of type integer of size 5.
        int[] numbers = new int[5];
        numbers[2]= 75;
        numbers[4]= 27;
        //number[5] = 34; //exception as it does not exist.
        
        
        for(int i=0; i<numbers.length; i++)
        {
            numbers[i] = (int) Math.pow(2, i);
        }
        
        for(int i=0; i<numbers.length; i++)
        {
            System.out.println(numbers[i]);  
        }
        
        for(int i:numbers){
            System.out.println(i);
            
        }
    }
    
}
