/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author S547509
 */
public class calculator {
    private int num1;
    private int num2;

    public calculator(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    
    public int add(){
        return num1+num2;
        
    }
    
    public int sub(){
        if(num2>num1){
            throw new OverDraftException("cannot have negative balance");
        }
        return num1-num2;
    }
    
    public int mul(){
        return num1*num2;
    }
    
    public int div(){
        
        if(num2==0){
            //exception should occur;
            throw new DividedByZeroException("Division by zero is not possible");
        }
        return num1/num2;
    }
    
}
