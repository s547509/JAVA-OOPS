
import java.util.InputMismatchException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author S547509
 */
public class calcDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        calculator calc = new calculator(5,6);
        try{
        System.out.println(calc.add());
        System.out.println(calc.sub());
        System.out.println(calc.div());
        System.out.println(calc.mul());
        // TODO code application logic here
    }catch( DividedByZeroException | InputMismatchException | ArithmeticException ex){
            System.out.println(ex + "___" + ex.getMessage());
    }
        finally{
            System.out.println("Finally block executes all the time.");
                    }
    }
    
}
