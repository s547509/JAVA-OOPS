
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author S547509
 */
public class OverDraftException extends IOException {

    public OverDraftException() {
    }

    public OverDraftException(String message) {
        super(message);
    }

    public OverDraftException(String message, Throwable cause) {
        super(message, cause);
    }

    public OverDraftException(Throwable cause) {
        super(cause);
    }
    

   
    
}
