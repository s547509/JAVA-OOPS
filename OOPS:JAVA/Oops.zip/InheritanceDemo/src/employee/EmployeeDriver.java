/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employee;

/**
 *
 * @author S547509
 */
public class EmployeeDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Employee emp = new Employee("john", "Smith", "123-45-678");
        System.out.println(emp.getFullName());
        System.out.println(emp.toString());
        
        HourlyEmployee hrEmp = new HourlyEmployee(10, 15,'f', "Bob",
        "Williams", "456789q789");
        System.out.println(hrEmp.calcSalary());
        System.out.println(hrEmp.toString());
        System.out.println(hrEmp.getGender_Specific());
        
        //polymorphic substitution
        // emp = hrEmp;//assigning a subclass object to superclass object
         hrEmp = (HourlyEmployee) emp;
        System.out.println(emp);
        System.out.println(emp.getFullName());
        
    }
    
}
