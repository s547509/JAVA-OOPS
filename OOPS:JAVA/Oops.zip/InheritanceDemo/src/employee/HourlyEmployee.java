/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */ 
package employee;

/**
 *
 * @author S547509
 */
public class HourlyEmployee extends Employee {
    private int noOfHoursWorked;
    private double wageRate;
    private char gender;

    public HourlyEmployee(int noOfHoursWorked, double wageRate, String firstName, String lastName, String ssn) {
        super(firstName, lastName, ssn);
        this.noOfHoursWorked = noOfHoursWorked;
        this.wageRate = wageRate;
    }

    public HourlyEmployee(int noOfHoursWorked, double wageRate, char gender, String firstName, String lastName, String ssn) {
        super(firstName, lastName, ssn);
        this.noOfHoursWorked = noOfHoursWorked;
        this.wageRate = wageRate;
        this.gender = gender;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }
    
    

    public int getNoOfHoursWorked() {
        return noOfHoursWorked;
    }

    public double getWageRate() {
        return wageRate;
    }

    public void setNoOfHoursWorked(int noOfHoursWorked) {
        this.noOfHoursWorked = noOfHoursWorked;
    }

    public void setWageRate(double wageRate) {
        this.wageRate = wageRate;
    }
    public double calcSalary(){
        return noOfHoursWorked * wageRate;
        
    }
    
    public String getGender_Specific() {
        if (gender == 'F'|| gender=='f') {
            return "female";
        } else if (gender == 'M' || gender=='m') {
            return "male";
        } else {
            return "other";
        }

        
    }
   
    @Override
    public String getFullName(){
        return super.getFirstName()+ " "
                + super.getLastName();
    }
    
    @Override
    public String toString(){
        return super.toString() + " "+ calcSalary();
    }
}