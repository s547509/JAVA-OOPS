/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linkedlistdemo;

import static java.nio.file.Files.list;
import static java.util.Collections.list;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

/**
 *
 * @author S547509
 */
public class Linkedlistdemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       LinkedList<Integer> myList = new LinkedList<Integer> ();
       myList.add(0);
       myList.add(1);
       myList.add(2);
       myList.add(4);
       myList.add(7);
       myList.add(13);
       myList.add(17);
       
       
       
       
       myList.add(0,1);
       myList.add(30);
       
        System.out.println("printing list elements using for loop");
       
       for(int N : myList){
           System.out.println(N);
          
       }
       
        System.out.println("printing list elements using Iterator");
     
       Iterator itr = myList.iterator();
       while(itr.hasNext()){
           System.out.println(itr.next());
       }
       
       
       System.out.println("printing list elements using ListIterator in reverse order");
        
       ListIterator itr2 = myList.listIterator();
       while(itr2.hasPrevious())
       {
           System.out.println(itr2.previous());
       }
       
       
        System.out.println("printing list elements using ListIterator");
       ListIterator itr1 = myList.listIterator();
       while(itr1.hasNext())
       {
           System.out.println(itr1.next());
       }
       
       
       
      // myList.remove(30);
      // myList.remove(Integer.valueOf(1));
        System.out.println(myList);
       
       System.out.println("printing list elements within given elements within sorted order");
        
      Scanner scan = new  Scanner(System.in);
      System.out.println("Enter any number between 0 to " + (myList.size()-1));
      int n = scan.nextInt();
      for(int a=0;a<=n;a++){
          System.out.println(myList.get(a));
      }
      
        System.out.println("Printing list elements within given limit in reverse sorted order");
        
               
        System.out.println("enter any number between 0 to " + (myList.size()-1));
        int n1 = scan.nextInt();
        for(int a=n1;a>=0;a--){
            System.out.println(myList.get(a));
        }
               
       
        
       
      
           
   
    }
    
}
