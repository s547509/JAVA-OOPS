/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dogs;

import java.util.ArrayList;

/**
 *
 * @author S547509
 */
public class DogDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Dog> myDogs = new ArrayList<Dog>();
        myDogs.add(new Dog("puppy",1,22));
        myDogs.add(new Dog("jimmy",2,22.2));
        myDogs.add(new Dog("leo",3,33.3));
        myDogs.add(new Dog("indi",4,44.4));
        myDogs.add(new Dog("navi",5,33));
        
        double sum=0;
        double average=0;
        int count=0;
        for(Dog d:myDogs){
            sum=sum+d.getPrice();
            count++;
        }
        average=sum/count;
        System.out.println(average);
        
    }
    
}
