/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defaultmethods;

/**
 *
 * @author Rohith Reddy Annadi
 */
public interface Interface02 {
    /**
     * This method provides us String
     * @param myString
     * @return myString
     */
    
    default int goo(String myString){
        System.out.println("Inside Interface02 – goo");
        return myString.indexOf("o");
    }
}
