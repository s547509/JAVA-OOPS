/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defaultmethods;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class MyClass implements Interface01, Interface02 {
    /**
     * This method provides us integer
     * @return myInt
     */

    @Override
    public int foo(int myInt){
        System.out.println("Inside MyClass-foo");
        return myInt*2;
    }
    
    /**
     * This method provides us String
     * @return myString
     */

    @Override
    public int goo(String myString) {
        
        System.out.println("Inside MyClass – goo");
        //return Interface02.super.goo(myString);
        return myString.lastIndexOf("o");// Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
}
