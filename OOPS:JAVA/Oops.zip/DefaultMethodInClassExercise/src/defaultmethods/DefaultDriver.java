/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package defaultmethods;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class DefaultDriver {
    
    public static void main(String[] args) {
        // TODO code application logic here
        /**
         * @param args the command line arguments
         */
   
        MyClass class01 = new MyClass();
        System.out.println(class01.foo(3));
        System.out.println(class01.goo("Goodbye"));
        
    }
    
}


