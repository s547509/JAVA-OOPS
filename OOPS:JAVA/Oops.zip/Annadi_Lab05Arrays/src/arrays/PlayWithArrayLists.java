/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrays;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class PlayWithArrayLists {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                
        ArrayList<String> moviesAL=new ArrayList<String>();
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the movie names :");
        for(int i=0;i<4;i++){
          
            moviesAL.add(scan.nextLine());
            
        }
        System.out.println("Enter the double elements: ");
        ArrayList<Double> doubleAL=new ArrayList<Double>();
        for(int i=0;i<5;i++){
          
            doubleAL.add(scan.nextDouble());
            
        }
        ArrayList<Integer> intAL=new ArrayList<Integer>();
        System.out.println("Enter the double elements: ");
        for(int i=0;i<6;i++){
          
            intAL.add(scan.nextInt());
            
        }
        System.out.println("*****************TRAVERSE********************");
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
        
        
        System.out.println("*****************INSERTION********************");
        moviesAL.add(2, "Avengers");
        System.out.println(moviesAL);
        
        doubleAL.add(2,20.89);
        System.out.println(doubleAL);
        
        intAL.add(2,369);
        System.out.println(intAL);
        
        System.out.println("*****************DELETION********************");
        moviesAL.remove(1);
        System.out.println(moviesAL);
        
        doubleAL.remove(1);
        System.out.println(doubleAL);
        
        intAL.remove(1);
        System.out.println(intAL);
        
        System.out.println("*****************SEARCH********************");
        System.out.println("Index of Avengers element in moviesAL is "+moviesAL.indexOf("Avengers"));
        System.out.println("Index of 20.89 element in doubleAL is "+doubleAL.indexOf(20.89));
        System.out.println("Index of 369 element in intAL is "+intAL.indexOf(369));
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
        
        System.out.println("*****************UPDATION********************");
        
        moviesAL.remove(String.valueOf("Avengers"));
        doubleAL.remove(Double.valueOf("20.89"));
        intAL.remove(Integer.valueOf("369"));      
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
        
        
    }
    
}
