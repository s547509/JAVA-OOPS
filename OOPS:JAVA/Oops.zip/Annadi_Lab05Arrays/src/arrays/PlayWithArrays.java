/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrays;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class PlayWithArrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String[] moviesA = new String[5];
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the movies array elements :");
        for(int i=0; i<moviesA.length-1; i++)
        {
            moviesA[i] = scan.nextLine();
        }
        double[] doubleA = new double[6];
        System.out.println("Enter the double array elements :");
        for(int i=0; i<doubleA.length-1; i++)
        {
            doubleA[i] = scan.nextDouble();
        }
        int[] intA = new int[7];
        System.out.println("Enter the integer array elements :");
        for(int i=0; i<intA.length-1; i++)
        {
            intA[i] = scan.nextInt();
        }
        System.out.println("*****************TRAVERSE********************");
        System.out.println(Arrays.toString(moviesA));
        System.out.println(Arrays.toString(doubleA));
        System.out.println(Arrays.toString(intA));
        System.out.println("Array movies before insertion :");
        for(int i=0; i<moviesA.length; i++)
        {
            System.out.print(moviesA[i]+ " ");  
        }
        System.out.println("");
        System.out.println("Array double elements before insertion :");
        for( int i=0; i<doubleA.length; i++)
        {
            System.out.print(doubleA[i]+ " ");
        }
        System.out.println("");
        System.out.println("Array integer elements before insertion :");
        for( int i=0; i<intA.length; i++)
        {
            System.out.print(intA[i]+ " ");
        }
        System.out.println("");
        int n=2;     
        System.out.println("*****************INSERTION********************");
        System.out.println("movies array elements after insertion:");
        for(int i=moviesA.length-1;i>n;i--){
            int j=i-1;
            moviesA[i]=moviesA[j];
        }
        moviesA[n]="Avengers";
        for(int i=0;i<moviesA.length;i++){
            
             System.out.print(moviesA[i]+" ");
        }
        System.out.println("");
        
       
        System.out.println("doubleArray elements after insertion:");
         for(int i=doubleA.length-1;i>n;i--){
            int j=i-1;
            doubleA[i]=doubleA[j];
        }
        
        doubleA[n]=20.89;
        for(int i=0;i<doubleA.length;i++){
            
             System.out.print(doubleA[i]+" ");
        }
         System.out.println("");
         System.out.println("intArray elements after insertion:");
          for(int i=intA.length-1;i>n;i--){
            int j=i-1;
            intA[i]=intA[j];
        }
        
        intA[n]=369;
         for(int i=0;i<intA.length;i++){
            
            System.out.print(intA[i]+" ");
        }
        System.out.println("");
        
        
        
        System.out.println("*****************DELETION********************");
        System.out.println("Array movies elements after deleting: ");
        int k=1;
        for(int i=k;i<moviesA.length-1;i++)
        {
            moviesA[i]=moviesA[i+1];
        }
        for(int i=0;i<moviesA.length-1;i++){
            
             System.out.print(moviesA[i]+" ");
        }
        System.out.println("");
        System.out.println("doubleArray elements after deleting:");
        for(int i=k;i<doubleA.length-1;i++)
        {
            doubleA[i]=doubleA[i+1];
        }
        for(int i=0;i<doubleA.length-1;i++){
            
             System.out.print(doubleA[i]+" ");
        }
         System.out.println("");
        System.out.println("intArray elements after deleting:");
        for(int i=k;i<intA.length-1;i++)
        {
            intA[i]=intA[i+1];
        }
        for(int i=0;i<intA.length-1;i++){
            
            System.out.print(intA[i]+" ");
        }
        System.out.println("");
        
        System.out.println("*****************SEARCH********************");
        int p=0;
        for(int i=0;i<moviesA.length;i++)
        {
            if(moviesA[i].equals("Avengers"))
            {
                p=i;
                break;
              
            }
      
        }
          System.out.println("Element Avengers Found at index "+p+" of movies");
       int l=0;
        for(int i=0;i<doubleA.length;i++)
        {
            if(doubleA[i]==20.89)
            {
                l=i;
               break;
            }
      
        }
        System.out.println("Element 20.89 Found at index "+k+" of doubleArray");
       int m=0;
        for(int i=0;i<intA.length;i++)
        {
            if(intA[i]==369)
            {
               
              m=i;
              break;
            }
      
        }
        System.out.println("Element 369 Found at index "+l+" of intArray");
        
        System.out.println("*****************UPDATE********************");
        
        moviesA[1]="WonderWoman";
        doubleA[1]=67.45;
        intA[1]=729;
        System.out.println("movies after updating: ");
        for(int i=0;i<moviesA.length-1;i++){
            
             System.out.print(moviesA[i]+" ");
        }
        System.out.println("");
        
        System.out.println("doubleArray elements after updating:  ");
        for(int i=0;i<doubleA.length-1;i++){
            
             System.out.print(doubleA[i]+" ");
        }
        System.out.println("");
         System.out.println("intArray elements after updating: ");
        for(int i=0;i<intA.length-1;i++){
            
            System.out.print(intA[i]+" ");
        }
        System.out.println("");
    }
    
}
