/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pizzas;

import java.time.DayOfWeek;
import java.time.LocalDate;

/**
 *
 * @author S547509
 */
public class PizzaDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(PizzaCost.LARGE.getPrice());
        
        
        for(PizzaCost pizza:PizzaCost.values())
        {
            System.out.println(pizza+" pizza is of $"+pizza.getPrice());
        }
        PizzaCost valueOf = PizzaCost.valueOf("SMALL");
        System.out.println(valueOf.getPrice());
        
        System.out.println(PizzaCost.MEDIUM.getDiscountRate());
          for(PizzaCost pizza:PizzaCost.values())
        {
            System.out.println(pizza+" pizza is of $"+pizza.getPrice()+
                    " Price after discount is: "+pizza.priceAfterDiscount());
        }
          for(PizzaCost p : PizzaCost.values()){
            
              boolean weekend = PizzaDriver.isWeekend(2021, 3, 14);
            
              if(weekend){
                System.out.println(p+" pizza with discount : "+p.priceAfterDiscount());
            }
            else{
                System.out.println(p+" pizza without discount :"+p.getPrice());
            }
          }
    }
    
    private static boolean isWeekend(int year, int month, int day)
    {
       LocalDate date = LocalDate.of(year, month, day);
       DayOfWeek today = date.getDayOfWeek();
       if(today.equals(DayOfWeek.SATURDAY) ||
               today.equals(DayOfWeek.SUNDAY))
       {
           return true;
       }
       else
       {
           return false;
       }
     }
    
}
