/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pizzas;

/**
 *
 * @author S547509
 */
public enum PizzaCost {
    SMALL(5,0.2), MEDIUM(7.5,0.5), LARGE(10,1), XL(12,1.2);
    
    private double price;
    private double discountRate;

    private PizzaCost(double price, double discountRate) {
        this.price = price;
        this.discountRate = discountRate;
        
    }

    public double getPrice() {
        return price;
    }
    

    public double getDiscountRate() {
        return discountRate;
    }
    
    public double priceAfterDiscount(){
        price = price-(price*discountRate/100);
        return price;
    }
    
}
