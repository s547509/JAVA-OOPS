/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gas;

/**
 *
 * @author s547509
 */
public class HalfGA extends GradAssistant {

    public HalfGA(String name, String ssn) {
        super(name, ssn);
    }

    @Override
    public double calcSalary() {
        return 0.5*MAX_SALARY;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double calcTuition() {
        return 0.5*MAX_TUITION_WAIVER;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
