/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gas;

/**
 *
 * @author s547509
 */
public interface Payable {
    public static final double MAX_SALARY = 750;
    public static final double MAX_TUITION_WAIVER = 3000;
    
    
    public abstract double calcSalary();
    public abstract double calcTuition();
}
