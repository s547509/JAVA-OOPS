/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gas;

/**
 *
 * @author s547509
 */
public class ThreeFourthGA extends GradAssistant {

    public ThreeFourthGA(String name, String ssn) {
        super(name, ssn);
    }

    @Override
    public double calcSalary() {
        return 0.75*MAX_SALARY;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double calcTuition() {
        return MAX_TUITION_WAIVER*3/4.0;
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
