/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gas;

/**
 *
 * @author s547509
 */
public class FullGA extends GradAssistant {

    public FullGA(String name, String ssn) {
        super(name, ssn);
    }

   

    @Override
    public double calcSalary() {
        return MAX_SALARY;
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double calcTuition() {
        return MAX_TUITION_WAIVER;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
    
}
