package worksheets;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author S547509
 */
public class WorkSheet1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       String r = new String("I love Java");
       String s = new String("  Jumping Jeroos  ");
       String t = new String( "bearcat" );
       String u = new String( "northwest" );
        System.out.println(s.toUpperCase());
        System.out.println(s.trim().toUpperCase());
    }
    
}
