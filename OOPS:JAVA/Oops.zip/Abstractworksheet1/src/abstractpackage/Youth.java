/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractpackage;

/**
 *
 * @author s547509
 */
public class Youth extends Exhibitor {

    private static final int PTS_NEEDED = 250;
    private static final int NUMBER_OF_EVENTS = 2;
    private int numEvents;

    public Youth() {
    }

   

    public Youth(int numEvents, String lastName, String firstName, int yearOfBirth, int points) {
        super(lastName, firstName, yearOfBirth, points);
        this.numEvents = numEvents;
    }

    public int getNumEvents() {
        return numEvents;
    }

    public void setNumEvents(int numEvents) {
        this.numEvents = numEvents;
    }

    @Override
    public boolean worldShowQualified() {
         if(points>=PTS_NEEDED&& numEvents >= NUMBER_OF_EVENTS){
            return true;
            
        } else{
            return false;
        }
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    

}
