/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package abstractpackage;

/**
 *
 * @author s547509
 */
public class ExhibitorDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Exhibitor Eh = new Amateur("parrot","whale",1996,150);
        Exhibitor Ey = new Youth(11,"Annadi","Rohith",1999,110);
        System.out.println(Eh.worldShowQualified());
        System.out.println(Ey.worldShowQualified());
        // TODO code application logic here
    }
    
}
