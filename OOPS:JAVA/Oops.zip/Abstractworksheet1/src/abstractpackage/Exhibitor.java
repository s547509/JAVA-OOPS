/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractpackage;

/**
 *
 * @author s547509
 */
public abstract class Exhibitor {

    private String lastName;
    private String firstName;
    private int yearOfBirth;
    public int points;

    public Exhibitor() {
    }

    public Exhibitor(String lastName, String firstName, int yearOfBirth, int points) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.yearOfBirth = yearOfBirth;
        this.points = points;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    @Override
    public String toString() {
        return "Exhibitor{" + "lastName=" + lastName + ", firstName=" + firstName + ", yearOfBirth=" + yearOfBirth + ", points=" + points + '}';
    }
    
    public abstract boolean worldShowQualified();

}
