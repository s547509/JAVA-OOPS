/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trees;

/**
 *
 * @author S547509
 */
public class TreeClass {

    /**
     * @param args the command line arguments
     */
   private String name;
   private double height;
   private boolean fruits;
    
   public  TreeClass(String nameIn,double heightIn,boolean fruitsIn )
   {
       name = nameIn;
       height = heightIn;
       fruits = fruitsIn;
       
   }
   public String getName()
   {
       return name;
   }
   public double getheight()
   {
       return height;
       
   }
   public boolean isfruits()
   {
       return fruits;
   }
   public void setName(String nameIn)
   {
       name= nameIn;
   }
   public void setHeight(double heightIn)
   {
       height= heightIn;
   }
   public void setFruits(boolean fruitsIn)
   {
       fruits=fruitsIn;
       
   }
    public String toString()
        {
            return " Tree Name = " + name +  
                    " Tree Height = " + height + 
                    " Tree Fruits + " + fruits + 
                    " I am done!";
            
           // return name + "-" + height + "-" + fruits;
            
        }
        
    
    }
    

