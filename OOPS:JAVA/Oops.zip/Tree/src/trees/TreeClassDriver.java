/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trees;

/**
 *
 * @author S547509
 */
public class TreeClassDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
  TreeClass t1 = new TreeClass("mango",3.2,true);
  TreeClass t2 = new TreeClass("apple",4.2,true);
  TreeClass t3 = new TreeClass("Orange",3.0,true);
  
        
        System.out.println(t1.toString());
  
        System.out.println(t2.toString());
        
        
    }
    
    
}
