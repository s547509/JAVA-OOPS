/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InterfacesAndAbstractClasses;

import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class WallGreen implements Medicine  {

    private double total;
    
    /**
     * This is the constructor for WallGreen class
     */

    public WallGreen() {
        this.total = 0.0;
    }
    
    /**
     * This method gives us total
     * @return total
     */

    @Override
    public double getTotal() {
        return total;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    /**
     * This method gives us the item name
     */

    @Override
    public void buyItems() {
        boolean moreItem = true;

        Scanner sc = new Scanner(System.in);
        while (moreItem) {
            System.out.println("Enter the name of medicine:");
            String item = sc.next();
            System.out.println("Enter the price of " + item + ":");

            double price = sc.nextDouble();
            total = total + price;
            sc.nextLine();
            System.out.println("Do you want to buy more medicines (Y/N):");

            char haveMore = sc.next().charAt(0);
            if (haveMore == 'Y') {
                moreItem = true;

            } else {
                moreItem = false;
            }

        }//throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
