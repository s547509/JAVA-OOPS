/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InterfacesAndAbstractClasses;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class MedicineStore extends Store {
    
    /**
     * This method gives us Grocery store name
     * @return GroceryStore
     */

    @Override
    public Grocery createGroceryStore(String name) {
        return null;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    /**
     * This method gives us Medicine store name
     * @return MedicineStore
     */

    @Override
    public Medicine createMedicineStore(String name) {
        Medicine medcn = null;
        if (name.equals("Wallgreen")) {
            medcn = new WallGreen();
        } else if (name.equals("Mosaic")) {
            medcn = new Mosaic();
        }
        return medcn;

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
