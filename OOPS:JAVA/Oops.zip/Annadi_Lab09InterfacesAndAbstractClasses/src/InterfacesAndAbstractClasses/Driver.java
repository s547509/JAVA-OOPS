/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package InterfacesAndAbstractClasses;

import java.util.Scanner;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        Creator c = new Creator();
        System.out.print("Enter what you want to buy (Grocery/Medicine):");
        String s = sc.nextLine();
        Store st = c.createStore(s);
        double total = 0.0;
        if (s.equals("Grocery")) {
            System.out.print("Enter the grocery store name from which you want to buy (Wallmart/Hyvee):");
            String storeName = sc.nextLine();
            Grocery gr = st.createGroceryStore(storeName);
            gr.buyItems();
            total = gr.getTotal();
        } else if (s.equals("Medicine")) {
            System.out.print("Enter the medicine store name from which you want to buy (Wallgreen/Mosaic):");
            String medicineName = sc.nextLine();
            Medicine md = st.createMedicineStore(medicineName);
            md.buyItems();

            total = md.getTotal();
        }
        System.out.println("Total price for the shopping is:" + total);
    }
    
    
}
