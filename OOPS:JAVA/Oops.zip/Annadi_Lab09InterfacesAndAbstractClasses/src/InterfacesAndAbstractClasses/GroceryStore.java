/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InterfacesAndAbstractClasses;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class GroceryStore extends Store {
    
    /**
     * This method gives us Grocery store name
     * @return GroceryStore
     */

    @Override
    public Grocery createGroceryStore(String name) {
        Grocery gr = null;
        if ("Wallmart".equals(name)) {
            gr = new Wallmart();
        } else if ("Hyvee".equals(name)) {
            gr = new Hyvee();
        }
        return gr;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    /**
     * This method gives us Medicine store name
     * @return MedicineStore
     */

    @Override
    public Medicine createMedicineStore(String name) {
        return null;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    }

}
