/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InterfacesAndAbstractClasses;

/**
 *
 * @author Rohith Reddy Annadi
 */
public class Creator {
    
    /**
     * This method gives us store name
     * @param name takes store name
     * @return Store
     */
    
    public Store createStore(String name) {
        Store s = null;
        if (name.equals("Grocery")) {
            s = new GroceryStore();
        } else if (name.equals("Medicine")) {
            s = new MedicineStore();
        }
        return s;

    }
}
